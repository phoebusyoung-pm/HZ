const page = document.body.dataset.page || "dashboard";

const enterpriseNav = [
  ["dashboard.html","dashboard","◫","企业工作台"],
  ["basic-info.html","basic-info","▤","基础信息"],
  ["product-info.html","product-info","▣","企业及展品"],
  ["brand-info.html","brand-info","✦","宣传资料"],
  ["booth-standard.html","booth-standard","⌂","标展服务"],
  ["booth-green.html","booth-green","♻","绿搭管理"],
  ["booth-raw.html","booth-raw","◇","光地管理"],
  ["notice.html","notice","▧","报到通知书"],
  ["progress.html","progress","◉","进度中心"],
  ["message.html","message","✉","消息中心"]
];

const adminNav = [
  ["admin-dashboard.html","admin-dashboard","◫","管理总览"],
  ["admin-exhibition.html","admin-exhibition","▦","展会管理"],
  ["admin-enterprise.html","admin-enterprise","♙","企业管理"],
  ["admin-review-green.html","admin-review-green","♻","绿搭审核"],
  ["admin-review-raw.html","admin-review-raw","◇","光地审核"],
  ["admin-notice.html","admin-notice","▧","通知书管理"],
  ["admin-message.html","admin-message","✉","消息系统"],
  ["admin-cert.html","admin-cert","♧","证件管理"]
];

const meta = {
  "dashboard": ["企业工作台","欢迎回来，集中查看参展进度与重要待办"],
  "basic-info": ["基础信息确认","确认企业联络信息与展位楣板内容"],
  "product-info": ["企业及展品信息","维护产品品类并提交经营资质材料"],
  "brand-info": ["企业宣传资料","完善 LOGO、会刊资料与企业简介"],
  "booth-standard": ["标展服务","查看标准展位信息与现场服务入口"],
  "booth-green": ["绿搭画面管理","上传制作画面，跟踪单图审核与效果图确认"],
  "booth-raw": ["光地搭建管理","提交搭建商、图纸及安全承诺材料"],
  "notice": ["报到通知书","查看参展报到信息并下载电子通知书"],
  "progress": ["进度中心","跟踪从资料确认到证件注册的完整进度"],
  "message": ["消息中心","集中接收审核、修改与截止日期提醒"],
  "admin-dashboard": ["展会管理总览","掌握企业报名、审核与异常处理数据"],
  "admin-exhibition": ["展会管理","创建展会并配置展位类型与业务截止时间"],
  "admin-enterprise": ["企业管理","管理参展企业、展位分配与楣板信息"],
  "admin-review-green": ["绿搭审核","逐图审核企业画面并反馈修改意见"],
  "admin-review-raw": ["光地审核","审核搭建商资质、工程图纸与安全文件"],
  "admin-notice": ["通知书管理","编辑通知书模板并管理 PDF 生成记录"],
  "admin-message": ["消息系统","管理短信、站内信与自动通知记录"],
  "admin-cert": ["证件管理","查看人员注册状态并导出制证名单"]
};

const badge = (text, type="default") => `<span class="badge ${type}">${text}</span>`;
const button = (text, cls="primary", extra="") => {
  const customClass = extra.match(/\bclass="([^"]*)"/);
  const className = customClass ? customClass[1] : `btn ${cls}`;
  const attrs = customClass ? extra.replace(customClass[0], "") : extra;
  return `<button class="${className}" ${attrs}>${text}</button>`;
};
const progress = (name, value, status="") => `
  <div class="progress-row">
    <div class="progress-meta"><span>${name}</span><strong>${value}%</strong></div>
    <div class="progress ${status}"><span style="width:${value}%"></span></div>
  </div>`;
const fileRow = (name, state="已上传", type="success") => `
  <div class="file-row">
    <div class="file-meta"><span>📄</span><span class="file-name">${name}</span></div>
    <div>${badge(state,type)} <span class="link js-confirm" data-message="已打开文件预览">预览</span></div>
  </div>`;
const uploadZone = (label="点击或拖拽文件到此处") => `
  <div class="upload-zone js-upload">
    <div><div class="upload-icon">☁</div><div>${label}</div><div class="help">支持 JPG、PNG、PDF，单个文件不超过 20MB</div></div>
  </div>`;

function navHTML(items) {
  return items.map(([href,key,icon,label]) =>
    `<a href="${href}" class="nav-item ${page===key?"active":""}"><span class="nav-icon">${icon}</span><span>${label}</span></a>`
  ).join("");
}

function shell(content, admin=false) {
  const m = meta[page] || ["展务系统",""];
  const items = admin ? adminNav : enterpriseNav;
  return `
  <div class="shell">
    <aside class="sidebar">
      <div class="brand"><div class="brand-mark">${admin?"管":"展"}</div><div><strong>${admin?"展务管理平台":"企业展务中心"}</strong><small>EXHIBITION SERVICE</small></div></div>
      <div class="nav-label">${admin?"后台管理":"企业服务"}</div>
      ${navHTML(items)}
    </aside>
    <main class="main">
      <header class="topbar">
        <div class="crumb">2026 中国国际农业科技展 / ${m[0]}</div>
        <div class="top-actions"><a href="${admin?"admin-message.html":"message.html"}" class="bell">🔔</a><div class="user"><div class="avatar">${admin?"管":"华"}</div><div><strong>${admin?"展务管理员":"华丰农业科技"}</strong><div class="card-sub">${admin?"超级管理员":"A3-218"}</div></div></div></div>
      </header>
      <div class="content">
        <div class="page-head"><div><h1>${m[0]}</h1><p>${m[1]}</p></div><div class="head-actions">${admin?badge("展会进行中","success"):badge("距资料截止 8 天","warning")}</div></div>
        ${content}
      </div>
    </main>
  </div>${globalUI()}`;
}

function mobileShell(content, active="home", title="展务服务") {
  const links = [
    ["mini-home.html","home","⌂","首页"],
    ["mini-progress.html","progress","◉","进度"],
    ["mini-message.html","message","✉","消息"],
    ["mini-cert.html","cert","♧","证件"]
  ];
  return `<div class="mobile-page"><div class="phone">
    <div class="phone-top"><div class="phone-status"><span>09:41</span><span>● ● ▰</span></div><div class="phone-head"><h1>${title}</h1><span>•••</span></div></div>
    <div class="phone-content">${content}</div>
    <nav class="bottom-nav">${links.map(x=>`<a href="${x[0]}" class="${active===x[1]?"active":""}"><span>${x[2]}</span><span>${x[3]}</span></a>`).join("")}</nav>
  </div></div>${globalUI()}`;
}

function globalUI() {
  return `<div class="modal" id="actionModal"><div class="modal-mask modal-close"></div><div class="modal-box">
    <div class="modal-head"><strong id="modalTitle">操作确认</strong><button class="icon-btn modal-close">×</button></div>
    <div class="modal-body" id="modalBody">请确认本次操作。</div>
    <div class="modal-foot"><button class="btn modal-close">取消</button><button class="btn primary modal-submit">确认提交</button></div>
  </div></div><div class="toast" id="toast">操作成功</div>`;
}

const pages = {};

pages.dashboard = () => shell(`
  <div class="hero">
    <div><span class="hero-kicker">2026.09.18 — 09.20 · 上海国家会展中心</span><h2>2026 中国国际农业科技展</h2><p>展位 A3-218 · 绿搭展位 · 36㎡。请于 7 月 30 日前完成画面资料与参展人员证件注册。</p>
    <div class="head-actions">${button("查看参展进度","primary",'onclick="location.href=\'progress.html\'"')}${button("报到通知书","",'onclick="location.href=\'notice.html\'"')}</div></div>
  </div>
  <div class="grid grid-4" style="margin-top:16px">
    <div class="card stat-card"><span class="stat-icon">✓</span><div class="stat-label">企业信息完成度</div><div class="stat-value">78%</div><div class="stat-foot">还需完成 2 项资料</div></div>
    <div class="card stat-card"><span class="stat-icon">⌛</span><div class="stat-label">当前审核状态</div><div class="stat-value" style="font-size:22px">绿搭审核中</div><div class="stat-foot">预计 2 个工作日内完成</div></div>
    <div class="card stat-card"><span class="stat-icon">▧</span><div class="stat-label">展位信息</div><div class="stat-value">A3-218</div><div class="stat-foot">绿搭 · 36㎡</div></div>
    <div class="card stat-card"><span class="stat-icon">✉</span><div class="stat-label">未读消息</div><div class="stat-value">3</div><div class="stat-foot"><a class="link" href="message.html">进入消息中心 →</a></div></div>
  </div>
  <div class="grid grid-2" style="margin-top:16px">
    <div class="card"><div class="card-head"><div class="card-title">待办事项</div><a class="link" href="progress.html">查看全部</a></div>
      <ul class="list">
        <li class="list-item"><div class="list-main"><span class="dot-icon">🖼</span><div><div class="list-title">修改 2-反画面文件</div><div class="list-desc">图片存在安全区外文字，请于 7 月 26 日前重新提交</div></div></div>${badge("紧急","danger")}</li>
        <li class="list-item"><div class="list-main"><span class="dot-icon">♧</span><div><div class="list-title">完成参展人员证件注册</div><div class="list-desc">当前已注册 3/6 人</div></div></div>${badge("进行中","warning")}</li>
        <li class="list-item"><div class="list-main"><span class="dot-icon">✦</span><div><div class="list-title">补充会刊宣传资料</div><div class="list-desc">建议上传 300dpi 印刷版企业 LOGO</div></div></div>${badge("待完善","info")}</li>
      </ul>
    </div>
    <div class="card"><div class="card-head"><div class="card-title">资料审核概览</div><span class="text-muted">6 项</span></div>
      ${progress("基础信息",100,"success")}${progress("企业资质",100,"success")}${progress("宣传资料",75)}${progress("绿搭画面",63)}${progress("人员证件",50)}
    </div>
  </div>`);

pages["basic-info"] = () => shell(`
  <div class="card">
    <div class="card-head"><div><div class="card-title">企业基础信息</div><div class="card-sub">信息将用于会刊、楣板及通知书生成，请准确填写</div></div>${badge("已驳回","danger")}</div>
    <div class="alert danger">驳回原因：联系人手机号无法接通，请核对后重新提交。</div>
    <div class="form-grid">
      <div class="field"><label><span class="required">*</span>企业名称</label><input class="input" value="山东华丰农业科技有限公司"></div>
      <div class="field"><label><span class="required">*</span>联系人</label><input class="input" value="张敏"></div>
      <div class="field"><label><span class="required">*</span>联系电话</label><input class="input" value="138 6608 2219"></div>
      <div class="field"><label><span class="required">*</span>楣板信息</label><input class="input" value="山东华丰农业科技有限公司"><div class="help">默认使用企业名称，限 20 个汉字</div></div>
    </div>
    <div class="form-actions">${button("保存草稿","")}${button("重新提交","primary",'class="btn primary js-confirm" data-message="基础信息已重新提交审核"')}</div>
  </div>
  <div class="card"><div class="card-title">状态说明</div><div class="list-item"><span>资料尚未提交审核</span>${badge("未确认","default")}</div><div class="list-item"><span>企业已确认，等待展务使用</span>${badge("已确认","success")}</div><div class="list-item"><span>信息存在问题，需修改后重提</span>${badge("已驳回","danger")}</div></div>`);

pages["product-info"] = () => shell(`
  <div class="card">
    <div class="card-head"><div><div class="card-title">产品品类</div><div class="card-sub">可多选，用于展区与会刊分类</div></div>${badge("审核中","warning")}</div>
    <div class="check-row"><label class="check"><input type="checkbox" checked> 农药制剂</label><label class="check"><input type="checkbox" checked> 新型肥料</label><label class="check"><input type="checkbox"> 农业机械</label><label class="check"><input type="checkbox"> 种子种苗</label><label class="check"><input type="checkbox" checked> 生物技术</label></div>
  </div>
  <div class="card"><div class="card-head"><div><div class="card-title">企业及产品资质</div><div class="card-sub">请上传清晰、完整且在有效期内的扫描件</div></div><span class="text-muted">4 / 5 已上传</span></div>
    <div class="grid grid-3">
      <div class="upload-card"><div class="upload-name"><span>农药登记证</span>${badge("已通过","success")}</div>${fileRow("农药登记证_PD20260188.pdf")}</div>
      <div class="upload-card"><div class="upload-name"><span>肥料登记证</span>${badge("审核中","warning")}</div>${fileRow("肥料登记证_鲁农肥.pdf","审核中","warning")}</div>
      <div class="upload-card"><div class="upload-name"><span>生产许可证</span>${badge("已通过","success")}</div>${fileRow("生产许可证_2026.pdf")}</div>
      <div class="upload-card"><div class="upload-name"><span>检测报告</span>${badge("已驳回","danger")}</div>${uploadZone("重新上传检测报告")}<div class="reject-tip">检测报告缺少 CMA 章，请上传加盖有效印章的完整版本。</div></div>
      <div class="upload-card"><div class="upload-name"><span>营业执照</span>${badge("已通过","success")}</div>${fileRow("营业执照_副本.pdf")}</div>
    </div>
    <div class="form-actions">${button("保存草稿","")}${button("提交审核","primary",'class="btn primary js-confirm" data-message="资质材料已提交审核"')}</div>
  </div>`);

pages["brand-info"] = () => shell(`
  <div class="grid grid-2">
    <div class="card"><div class="card-head"><div><div class="card-title">企业 LOGO</div><div class="card-sub">建议透明底 PNG，尺寸不低于 1000×1000px</div></div>${badge("已上传","success")}</div>
      ${uploadZone("点击替换企业 LOGO")}${fileRow("huafeng-logo-print.png")}
    </div>
    <div class="card"><div class="card-head"><div><div class="card-title">会刊宣传资料</div><div class="card-sub">支持 PDF / AI 文件，大小不超过 50MB</div></div>${badge("待完善","warning")}</div>
      ${uploadZone("上传会刊广告或宣传页")}
    </div>
  </div>
  <div class="card"><div class="card-head"><div><div class="card-title">企业简介</div><div class="card-sub">将展示在电子会刊及小程序企业名片中</div></div><span class="text-muted">168 / 500</span></div>
    <textarea class="textarea">山东华丰农业科技有限公司专注于绿色农业投入品研发与生产，拥有生物农药、新型肥料及智慧植保三大产品线。公司坚持科技创新与可持续发展，为现代农业提供高效、安全、环保的综合解决方案。</textarea>
    <div class="form-actions">${button("保存资料","primary",'class="btn primary js-confirm" data-message="宣传资料已保存"')}</div>
  </div>`);

pages["booth-standard"] = () => shell(`
  <div class="grid grid-3">
    <div class="card span-2"><div class="card-head"><div><div class="card-title">标准展位信息</div><div class="card-sub">本届展会标准展位配置</div></div>${badge("已确认","success")}</div>
      <div class="grid grid-3"><div><div class="text-muted">展位号</div><h2>A3-218</h2></div><div><div class="text-muted">展位规格</div><h2>3m × 3m</h2></div><div><div class="text-muted">展位类型</div><h2>标准展位</h2></div></div>
      <div class="alert info">标准配置：咨询桌 1 张、折椅 2 把、射灯 2 盏、500W 插座 1 个、纸篓 1 个。</div>
    </div>
    <div class="card"><div class="card-title">现场服务</div><p class="text-muted">展位服务开放时间：8 月 1 日至 9 月 15 日</p>${button("下载报到通知书","primary block",'class="btn primary block js-download"')}${button("进入证件注册","block",'style="margin-top:10px" onclick="location.href=\'mini-cert.html\'"')}</div>
  </div>
  <div class="card"><div class="card-head"><div class="card-title">楣板信息确认</div>${badge("已确认","success")}</div>
    <div class="form-grid"><div class="field"><label>中文楣板</label><input class="input" value="山东华丰农业科技有限公司"></div><div class="field"><label>英文楣板</label><input class="input" value="SHANDONG HUAFENG AGRITECH CO., LTD."></div></div>
    <div class="form-actions">${button("申请修改","",'class="btn js-modal" data-title="申请修改楣板" data-body="楣板信息已进入制作流程。请填写修改原因，提交后由组委会确认是否可变更。"')}</div>
  </div>`);

const greenUploads = [
  ["1-正","green-front-v3.pdf","已通过","success",""],
  ["1-反","green-back-v2.pdf","已通过","success",""],
  ["2-正","panel-2-front.pdf","审核中","warning",""],
  ["2-反","panel-2-back.pdf","已驳回","danger","文字“全国第一”属于绝对化宣传用语，请修改后重新上传。"],
  ["1-1","detail-1-1.jpg","已通过","success",""],
  ["1-2","detail-1-2.jpg","审核中","warning",""],
  ["1-3","detail-1-3.jpg","未提交","default",""],
  ["1-4","detail-1-4.jpg","已通过","success",""]
];
pages["booth-green"] = () => shell(`
  <div class="alert warning">整体审核状态：${badge("需修改","danger")} 当前 8 个画面中，4 个已通过、2 个审核中、1 个被驳回、1 个未提交。</div>
  <div class="card">
    <div class="tabs"><button class="tab-btn active" data-tab="artwork">画面文件</button><button class="tab-btn" data-tab="effect">效果图确认</button><button class="tab-btn" data-tab="history">修改记录</button></div>
    <div class="tab-panel active" id="tab-artwork">
      <div class="grid grid-4">${greenUploads.map(([name,file,state,type,reason])=>`
        <div class="upload-card"><div class="upload-name"><span>画面 ${name}</span>${badge(state,type)}</div>
        ${state==="未提交"?uploadZone("上传画面 "+name):fileRow(file,state,type)}
        ${reason?`<div class="reject-tip">${reason}</div><button class="btn danger small js-modal" style="margin-top:10px" data-title="提交修改申请" data-body="请说明本次画面修改内容，审核通过后可上传替换文件。">申请修改</button>`:""}</div>`).join("")}
      </div>
      <div class="form-actions">${button("保存草稿","")}${button("提交全部画面","primary",'class="btn primary js-confirm" data-message="画面文件已提交审核"')}</div>
    </div>
    <div class="tab-panel" id="tab-effect">
      <div class="alert info">以下为搭建商根据已审核画面制作的展位效果图，请确认文字、图片和整体布局。</div>
      <div class="image-grid">${[1,2,3].map(i=>`<div class="effect-card"><img src="assets/green-booth.png" alt="效果图 ${i}"><div class="effect-info"><strong>效果图 ${i}</strong>${badge("待确认","warning")}</div></div>`).join("")}</div>
      <div class="form-actions">${button("反馈错误","danger",'class="btn danger js-modal" data-title="反馈效果图错误" data-body="请描述错误位置及正确内容，可由设计人员根据反馈重新出图。"')}${button("确认正确","success",'class="btn success js-confirm" data-message="3 张效果图已确认正确"')}</div>
    </div>
    <div class="tab-panel" id="tab-history">
      <div class="timeline"><div class="timeline-item fail"><span class="timeline-dot"></span><div class="timeline-title">画面 2-反审核驳回</div><div class="timeline-time">2026-07-21 14:32</div><div class="timeline-text">存在绝对化宣传用语，需重新修改。</div></div><div class="timeline-item done"><span class="timeline-dot"></span><div class="timeline-title">第一批画面提交审核</div><div class="timeline-time">2026-07-20 09:18</div></div></div>
    </div>
  </div>`);

pages["booth-raw"] = () => shell(`
  <div class="grid grid-4">
    <div class="card stat-card"><div class="stat-label">总体审核状态</div><div class="stat-value" style="font-size:22px">资料补正中</div><div class="stat-foot">${badge("已驳回","danger")}</div></div>
    <div class="card stat-card"><div class="stat-label">搭建商资质</div><div class="stat-value">2/2</div><div class="stat-foot">全部通过</div></div>
    <div class="card stat-card"><div class="stat-label">工程图纸</div><div class="stat-value">1/2</div><div class="stat-foot">电路图需修改</div></div>
    <div class="card stat-card"><div class="stat-label">安全文件</div><div class="stat-value">1/1</div><div class="stat-foot">审核通过</div></div>
  </div>
  <div class="card"><div class="card-title">搭建申报资料</div>
    <div class="grid grid-2" style="margin-top:16px">
      <div class="upload-card"><div class="upload-name"><span>搭建商营业执照及资质</span>${badge("已通过","success")}</div>${fileRow("远景会展搭建商资质.pdf")}</div>
      <div class="upload-card"><div class="upload-name"><span>展位平面图</span>${badge("已通过","success")}</div>${fileRow("A3-218_平面图_v2.pdf")}</div>
      <div class="upload-card"><div class="upload-name"><span>电路图</span>${badge("已驳回","danger")}</div>${uploadZone("重新上传电路图")}<div class="reject-tip">总功率标注与用电申请不一致，请补充配电箱位置和回路编号。</div></div>
      <div class="upload-card"><div class="upload-name"><span>安全搭建承诺书</span>${badge("已通过","success")}</div>${fileRow("安全搭建承诺书_盖章.pdf")}</div>
    </div>
    <div class="form-actions">${button("提交补充资料","primary",'class="btn primary js-confirm" data-message="补充资料已提交审核"')}</div>
  </div>`);

pages.notice = () => shell(`
  <div class="toolbar"><div></div><div class="toolbar-right">${button("下载 PDF","primary",'class="btn primary js-download"')}${button("打印","",'class="btn js-confirm" data-message="已调起模拟打印任务"')}</div></div>
  <div class="notice-paper"><h2>2026 中国国际农业科技展<br>参展商报到通知书</h2><div class="notice-no">通知书编号：CAATE-2026-A3-0218</div>
    <div class="notice-row"><strong>参展企业</strong><span>山东华丰农业科技有限公司</span></div>
    <div class="notice-row"><strong>展位信息</strong><span>A3-218 · 绿搭展位 · 36㎡</span></div>
    <div class="notice-row"><strong>报到时间</strong><span>2026 年 9 月 16 日 09:00—17:00</span></div>
    <div class="notice-row"><strong>报到地点</strong><span>上海国家会展中心 3H 馆参展商服务台</span></div>
    <div class="notice-row"><strong>布展时间</strong><span>2026 年 9 月 16—17 日</span></div>
    <div class="notice-body"><strong>报到流程</strong><ol><li>携带本通知书及企业有效证件至参展商服务台核验。</li><li>领取展商证、布展证及现场服务资料。</li><li>核对展位位置与基础设施，办理用电、网络等增值服务。</li><li>完成安全检查后方可进馆布展。</li></ol><p class="text-muted">请妥善保管本通知书。如有疑问，请联系组委会：021-8888 6600。</p></div>
  </div>`);

pages.progress = () => shell(`
  <div class="card"><div class="card-head"><div><div class="card-title">整体参展进度</div><div class="card-sub">预计完成时间：2026 年 8 月 15 日</div></div><strong class="text-success">72%</strong></div>
    <div class="steps">${[["基础信息","done","✓"],["资质审核","done","✓"],["绿搭/光地","current","3"],["通知书","","4"],["证件","","5"]].map(x=>`<div class="step ${x[1]}"><div class="step-icon">${x[2]}</div><div class="step-name">${x[0]}</div></div>`).join("")}</div>
  </div>
  <div class="card"><div class="card-title">事项明细</div>
    <div class="table-wrap"><table><thead><tr><th>流程事项</th><th>完成度</th><th>当前状态</th><th>更新时间</th><th>操作</th></tr></thead><tbody>
      <tr><td>基础信息确认</td><td>${progress("","100","success")}</td><td>${badge("已确认","success")}</td><td>07-12 10:20</td><td><a href="basic-info.html" class="link">查看</a></td></tr>
      <tr><td>企业及展品资质</td><td>${progress("","100","success")}</td><td>${badge("已通过","success")}</td><td>07-18 16:42</td><td><a href="product-info.html" class="link">查看</a></td></tr>
      <tr><td>绿搭画面审核</td><td>${progress("","63")}</td><td>${badge("需修改","danger")}</td><td>07-21 14:32</td><td><a href="booth-green.html" class="link">去修改</a></td></tr>
      <tr><td>报到通知书</td><td>${progress("","100","success")}</td><td>${badge("已生成","success")}</td><td>07-22 09:00</td><td><a href="notice.html" class="link">下载</a></td></tr>
      <tr><td>人员证件注册</td><td>${progress("","50")}</td><td>${badge("进行中","warning")}</td><td>07-22 11:10</td><td><a href="mini-cert.html" class="link">继续注册</a></td></tr>
    </tbody></table></div>
  </div>`);

pages.message = () => shell(`
  <div class="card"><div class="tabs"><button class="tab-btn active" data-tab="allmsg">全部消息</button><button class="tab-btn" data-tab="reviewmsg">审核通知</button><button class="tab-btn" data-tab="deadlinemsg">截止提醒</button></div>
    <div class="tab-panel active" id="tab-allmsg"><ul class="list">
      <li class="list-item"><div class="list-main"><span class="dot-icon" style="background:#ffebec;color:#e5484d">!</span><div><div class="list-title">绿搭画面“2-反”审核未通过</div><div class="list-desc">存在绝对化宣传用语，请修改后于 7 月 26 日前重新提交。</div><div class="card-sub">今天 14:32</div></div></div>${badge("审核失败","danger")}</li>
      <li class="list-item"><div class="list-main"><span class="dot-icon">✎</span><div><div class="list-title">基础信息修改提醒</div><div class="list-desc">联系人电话已由管理员退回，请核对后重新确认。</div><div class="card-sub">昨天 09:21</div></div></div>${badge("修改提醒","warning")}</li>
      <li class="list-item"><div class="list-main"><span class="dot-icon" style="background:#fff4dd;color:#b86e00">⌛</span><div><div class="list-title">证件注册截止提醒</div><div class="list-desc">距人员证件注册截止还有 8 天，当前完成 3/6 人。</div><div class="card-sub">07-20 10:00</div></div></div>${badge("截止提醒","warning")}</li>
      <li class="list-item"><div class="list-main"><span class="dot-icon" style="background:#e8f7ef;color:#18a058">✓</span><div><div class="list-title">报到通知书已生成</div><div class="list-desc">可前往通知书页面查看和下载 PDF 文件。</div><div class="card-sub">07-19 16:08</div></div></div>${badge("系统通知","info")}</li>
    </ul></div>
    <div class="tab-panel" id="tab-reviewmsg"><div class="empty"><div class="empty-icon">✉</div>已展示全部审核通知</div></div>
    <div class="tab-panel" id="tab-deadlinemsg"><div class="alert warning">人员证件注册将于 2026 年 7 月 30 日 18:00 截止。</div></div>
  </div>`);

pages["admin-dashboard"] = () => shell(`
  <div class="grid grid-4">
    <div class="card stat-card"><span class="stat-icon">♙</span><div class="stat-label">参展企业</div><div class="stat-value">386</div><div class="stat-foot text-success">↑ 12.4% 较上届</div></div>
    <div class="card stat-card"><span class="stat-icon">✓</span><div class="stat-label">综合审核通过率</div><div class="stat-value">82.6%</div><div class="stat-foot">1,248 项已完成</div></div>
    <div class="card stat-card"><span class="stat-icon">⌛</span><div class="stat-label">待审核事项</div><div class="stat-value">126</div><div class="stat-foot">绿搭画面占 58%</div></div>
    <div class="card stat-card"><span class="stat-icon" style="color:#e5484d;background:#ffebec">!</span><div class="stat-label">异常数据</div><div class="stat-value">17</div><div class="stat-foot text-danger">5 项临近截止</div></div>
  </div>
  <div class="grid grid-2" style="margin-top:16px">
    <div class="card"><div class="card-head"><div class="card-title">各流程完成情况</div><span class="text-muted">实时统计</span></div>${progress("基础信息确认",94,"success")}${progress("企业资质审核",83)}${progress("绿搭 / 光地审核",68)}${progress("通知书生成",72)}${progress("人员证件注册",55)}</div>
    <div class="card"><div class="card-head"><div class="card-title">今日待处理</div><a class="link" href="admin-review-green.html">进入审核台</a></div>
      <ul class="list"><li class="list-item"><span>绿搭画面待审核</span><strong>73</strong></li><li class="list-item"><span>光地图纸待审核</span><strong>21</strong></li><li class="list-item"><span>企业资料待审核</span><strong>18</strong></li><li class="list-item"><span>楣板修改申请</span><strong>14</strong></li></ul>
    </div>
  </div>
  <div class="card"><div class="card-head"><div class="card-title">异常企业预警</div>${badge("需关注","danger")}</div>
    <div class="table-wrap"><table><thead><tr><th>企业</th><th>展位</th><th>异常事项</th><th>距离截止</th><th>负责人</th><th>操作</th></tr></thead><tbody>
      <tr><td>华丰农业科技</td><td>A3-218</td><td>绿搭画面被驳回</td><td class="text-danger">2 天</td><td>李悦</td><td><a class="link" href="admin-review-green.html">处理</a></td></tr>
      <tr><td>中科肥业</td><td>B1-066</td><td>证件注册 0%</td><td class="text-danger">3 天</td><td>王晨</td><td><span class="link js-confirm" data-message="已发送催办通知">催办</span></td></tr>
    </tbody></table></div>
  </div>`,true);

pages["admin-exhibition"] = () => shell(`
  <div class="toolbar"><div class="toolbar-left"><select class="select"><option>2026 中国国际农业科技展</option><option>2025 农业科技创新展</option></select>${badge("进行中","success")}</div>${button("+ 创建展会","primary",'class="btn primary js-modal" data-title="创建新展会" data-body="填写展会名称、举办时间及场馆信息后即可创建新的展务项目。"')}</div>
  <div class="card"><div class="tabs"><button class="tab-btn active" data-tab="basecfg">基础配置</button><button class="tab-btn" data-tab="boothcfg">展位类型</button><button class="tab-btn" data-tab="deadlinecfg">截止时间</button></div>
    <div class="tab-panel active" id="tab-basecfg"><div class="form-grid"><div class="field"><label>展会名称</label><input class="input" value="2026 中国国际农业科技展"></div><div class="field"><label>展会地点</label><input class="input" value="上海国家会展中心"></div><div class="field"><label>开展日期</label><input class="input" type="date" value="2026-09-18"></div><div class="field"><label>结束日期</label><input class="input" type="date" value="2026-09-20"></div></div></div>
    <div class="tab-panel" id="tab-boothcfg"><div class="table-wrap"><table><thead><tr><th>类型</th><th>规格</th><th>企业数</th><th>资料流程</th><th>状态</th></tr></thead><tbody><tr><td>标准展位</td><td>3m × 3m</td><td>196</td><td>楣板 + 证件</td><td>${badge("启用","success")}</td></tr><tr><td>绿搭展位</td><td>18—72㎡</td><td>132</td><td>画面 + 效果图</td><td>${badge("启用","success")}</td></tr><tr><td>光地展位</td><td>36㎡起</td><td>58</td><td>搭建商 + 图纸 + 安全</td><td>${badge("启用","success")}</td></tr></tbody></table></div></div>
    <div class="tab-panel" id="tab-deadlinecfg"><div class="form-grid"><div class="field"><label>基础信息截止</label><input class="input" type="datetime-local" value="2026-07-15T18:00"></div><div class="field"><label>资质资料截止</label><input class="input" type="datetime-local" value="2026-07-22T18:00"></div><div class="field"><label>绿搭 / 光地截止</label><input class="input" type="datetime-local" value="2026-07-30T18:00"></div><div class="field"><label>证件注册截止</label><input class="input" type="datetime-local" value="2026-08-15T18:00"></div></div></div>
    <div class="form-actions">${button("保存配置","primary",'class="btn primary js-confirm" data-message="展会配置已保存"')}</div>
  </div>`,true);

pages["admin-enterprise"] = () => shell(`
  <div class="card"><div class="toolbar"><div class="toolbar-left"><input class="input search" placeholder="搜索企业名称 / 展位号"><select class="select"><option>全部展位类型</option><option>标准展位</option><option>绿搭</option><option>光地</option></select><select class="select"><option>全部状态</option><option>资料齐全</option><option>待完善</option></select></div><div class="toolbar-right">${button("导入企业","")}${button("+ 新增企业","primary",'class="btn primary js-modal" data-title="新增参展企业" data-body="录入企业基本信息后，可继续分配展位并发送账号邀请。"')}</div></div>
    <div class="table-wrap"><table><thead><tr><th><input type="checkbox"></th><th>企业名称</th><th>联系人</th><th>展位号</th><th>展位类型</th><th>楣板信息</th><th>资料状态</th><th>操作</th></tr></thead><tbody>
      <tr><td><input type="checkbox"></td><td>山东华丰农业科技有限公司</td><td>张敏<br><span class="text-muted">138****2219</span></td><td><strong>A3-218</strong></td><td>绿搭</td><td>山东华丰农业科技有限公司</td><td>${badge("待修改","danger")}</td><td class="table-actions"><span class="link js-modal" data-title="分配展位" data-body="当前展位 A3-218，可选择其他空闲展位重新分配。">分配展位</span><span class="link">编辑</span></td></tr>
      <tr><td><input type="checkbox"></td><td>中科新型肥业有限公司</td><td>刘浩</td><td>B1-066</td><td>标准展位</td><td>中科新型肥业</td><td>${badge("资料齐全","success")}</td><td class="table-actions"><span class="link">详情</span><span class="link">编辑楣板</span></td></tr>
      <tr><td><input type="checkbox"></td><td>禾润生物技术有限公司</td><td>孙晴</td><td>C2-106</td><td>光地</td><td>禾润生物科技</td><td>${badge("审核中","warning")}</td><td class="table-actions"><span class="link">详情</span><span class="link">编辑</span></td></tr>
      <tr><td><input type="checkbox"></td><td>丰源智慧农业股份有限公司</td><td>周宁</td><td>A2-088</td><td>绿搭</td><td>丰源智慧农业</td><td>${badge("资料齐全","success")}</td><td class="table-actions"><span class="link">详情</span><span class="link">编辑</span></td></tr>
    </tbody></table></div>
  </div>`,true);

pages["admin-review-green"] = () => shell(`
  <div class="grid grid-4"><div class="card stat-card"><div class="stat-label">待审核图片</div><div class="stat-value">73</div></div><div class="card stat-card"><div class="stat-label">今日已审核</div><div class="stat-value">48</div></div><div class="card stat-card"><div class="stat-label">驳回图片</div><div class="stat-value">9</div></div><div class="card stat-card"><div class="stat-label">平均耗时</div><div class="stat-value">3.2h</div></div></div>
  <div class="card"><div class="toolbar"><div class="toolbar-left"><input class="input search" placeholder="企业 / 展位号"><select class="select"><option>待审核</option><option>已通过</option><option>已驳回</option></select></div><span class="text-muted">共 73 条</span></div>
    <div class="table-wrap"><table><thead><tr><th>预览</th><th>企业 / 展位</th><th>画面编号</th><th>文件信息</th><th>智能检查</th><th>提交时间</th><th>操作</th></tr></thead><tbody>
      <tr><td><img class="review-thumb" src="assets/green-booth.png"></td><td>华丰农业科技<br><span class="text-muted">A3-218</span></td><td><strong>2-反</strong></td><td>panel-2-back.pdf<br><span class="text-muted">18.6MB · 300dpi</span></td><td>${badge("疑似违禁词","danger")}<br><span class="word-flag">全国第一</span></td><td>07-21 13:48</td><td class="table-actions"><button class="btn success small js-status">通过</button><button class="btn danger small js-modal" data-title="驳回画面 2-反" data-body="请选择驳回原因并填写修改要求，系统将自动通知企业联系人。">驳回</button></td></tr>
      <tr><td><img class="review-thumb" src="assets/green-booth.png"></td><td>丰源智慧农业<br><span class="text-muted">A2-088</span></td><td><strong>1-正</strong></td><td>front-final.jpg<br><span class="text-muted">12.2MB · 300dpi</span></td><td>${badge("检查通过","success")}</td><td>07-21 13:30</td><td class="table-actions"><button class="btn success small js-status">通过</button><button class="btn danger small js-modal" data-title="驳回画面" data-body="填写驳回原因后将通知企业修改。">驳回</button></td></tr>
      <tr><td><img class="review-thumb" src="assets/green-booth.png"></td><td>绿野植保<br><span class="text-muted">B2-109</span></td><td><strong>1-2</strong></td><td>detail-1-2.png<br><span class="text-muted">8.4MB · 150dpi</span></td><td>${badge("分辨率偏低","warning")}</td><td>07-21 12:51</td><td class="table-actions"><button class="btn success small js-status">通过</button><button class="btn danger small js-modal" data-title="驳回画面 1-2" data-body="建议上传不低于 300dpi 的印刷文件。">驳回</button></td></tr>
    </tbody></table></div>
  </div>`,true);

pages["admin-review-raw"] = () => shell(`
  <div class="card"><div class="tabs"><button class="tab-btn active" data-tab="rawall">全部待审</button><button class="tab-btn" data-tab="rawdrawing">工程图纸</button><button class="tab-btn" data-tab="rawsafe">安全文件</button></div>
    <div class="tab-panel active" id="tab-rawall"><div class="table-wrap"><table><thead><tr><th>企业 / 展位</th><th>资料类型</th><th>文件</th><th>搭建商</th><th>风险提示</th><th>状态</th><th>操作</th></tr></thead><tbody>
      <tr><td>禾润生物技术<br><span class="text-muted">C2-106 · 54㎡</span></td><td>展位平面图</td><td><span class="link">C2-106_平面图.pdf</span></td><td>远景会展工程</td><td>${badge("无异常","success")}</td><td>${badge("待审核","warning")}</td><td class="table-actions"><button class="btn success small js-status">通过</button><button class="btn danger small js-modal" data-title="驳回图纸" data-body="请填写图纸不符合搭建规范的具体位置。">驳回</button></td></tr>
      <tr><td>农科智造<br><span class="text-muted">D1-016 · 72㎡</span></td><td>电路图</td><td><span class="link">D1-016_电路_v1.pdf</span></td><td>创展空间</td><td>${badge("功率不一致","danger")}</td><td>${badge("待审核","warning")}</td><td class="table-actions"><button class="btn success small js-status">通过</button><button class="btn danger small js-modal" data-title="驳回电路图" data-body="用电申请为 12kW，图纸标注为 18kW，请企业核实。">驳回</button></td></tr>
      <tr><td>丰登种业<br><span class="text-muted">A1-028 · 36㎡</span></td><td>安全承诺书</td><td><span class="link">安全承诺书.pdf</span></td><td>嘉合展览</td><td>${badge("缺少骑缝章","warning")}</td><td>${badge("待审核","warning")}</td><td class="table-actions"><button class="btn success small js-status">通过</button><button class="btn danger small js-modal" data-title="驳回安全文件" data-body="文件缺少骑缝章，请补盖后重新扫描上传。">驳回</button></td></tr>
    </tbody></table></div></div>
    <div class="tab-panel" id="tab-rawdrawing"><div class="empty"><div class="empty-icon">◇</div>工程图纸筛选视图</div></div><div class="tab-panel" id="tab-rawsafe"><div class="empty"><div class="empty-icon">✓</div>安全文件筛选视图</div></div>
  </div>`,true);

pages["admin-notice"] = () => shell(`
  <div class="grid grid-2">
    <div class="card"><div class="card-head"><div><div class="card-title">通知书模板编辑</div><div class="card-sub">变量将在生成时自动替换</div></div>${badge("当前模板","success")}</div>
      <div class="field"><label>模板标题</label><input class="input" value="{{展会名称}}参展商报到通知书"></div>
      <div class="field" style="margin-top:15px"><label>正文内容</label><textarea class="textarea" style="min-height:300px">尊敬的 {{企业名称}}：

感谢参加 {{展会名称}}。贵司展位号为 {{展位号}}，请于 {{报到时间}} 前往 {{报到地点}} 办理报到手续。

请携带本通知书及企业有效证件，完成证件领取与展位核验。</textarea></div>
      <div class="form-actions">${button("预览模板","")}${button("保存模板","primary",'class="btn primary js-confirm" data-message="通知书模板已保存"')}</div>
    </div>
    <div class="card"><div class="card-head"><div class="card-title">批量生成</div>${badge("386 家企业","info")}</div><div class="alert info">当前有 278 家企业已满足通知书生成条件，108 家仍缺少必要信息。</div>
      <div class="field"><label>生成范围</label><select class="select"><option>全部符合条件企业（278）</option><option>选中的企业</option><option>指定展馆</option></select></div>
      <button class="btn primary block js-modal" style="margin-top:16px" data-title="批量生成 PDF" data-body="即将为 278 家企业生成报到通知书，预计需要 1—2 分钟。">生成 PDF</button>
      <div class="card-title" style="margin-top:28px">最近下载记录</div><ul class="list"><li class="list-item"><div><div class="list-title">华丰农业科技</div><div class="list-desc">CAATE-2026-A3-0218.pdf</div></div><span class="text-muted">07-22 10:31</span></li><li class="list-item"><div><div class="list-title">中科新型肥业</div><div class="list-desc">CAATE-2026-B1-0066.pdf</div></div><span class="text-muted">07-22 09:46</span></li></ul>
    </div>
  </div>`,true);

pages["admin-message"] = () => shell(`
  <div class="grid grid-4"><div class="card stat-card"><div class="stat-label">今日发送</div><div class="stat-value">1,286</div></div><div class="card stat-card"><div class="stat-label">短信送达率</div><div class="stat-value">98.7%</div></div><div class="card stat-card"><div class="stat-label">站内信已读率</div><div class="stat-value">76.4%</div></div><div class="card stat-card"><div class="stat-label">发送失败</div><div class="stat-value">12</div></div></div>
  <div class="card"><div class="toolbar"><div class="tabs" style="margin:0"><button class="tab-btn active" data-tab="sms">短信 / 站内信</button><button class="tab-btn" data-tab="auto">自动通知记录</button></div>${button("+ 新建消息","primary",'class="btn primary js-modal" data-title="新建消息" data-body="选择短信或站内信渠道、接收企业及消息模板后即可发送。"')}</div>
    <div class="tab-panel active" id="tab-sms"><div class="table-wrap"><table><thead><tr><th>消息标题</th><th>渠道</th><th>接收对象</th><th>发送时间</th><th>送达 / 已读</th><th>状态</th></tr></thead><tbody><tr><td>绿搭资料截止提醒</td><td>短信 + 站内信</td><td>132 家绿搭企业</td><td>07-22 10:00</td><td>130 / 98</td><td>${badge("发送完成","success")}</td></tr><tr><td>证件注册开放通知</td><td>站内信</td><td>全部企业</td><td>07-20 09:00</td><td>386 / 296</td><td>${badge("发送完成","success")}</td></tr></tbody></table></div></div>
    <div class="tab-panel" id="tab-auto"><div class="table-wrap"><table><thead><tr><th>触发规则</th><th>渠道</th><th>最近执行</th><th>通知数量</th><th>状态</th></tr></thead><tbody><tr><td>资料被驳回时即时通知</td><td>短信 + 站内信</td><td>今天 14:32</td><td>9</td><td>${badge("运行中","success")}</td></tr><tr><td>截止前 3 天提醒</td><td>短信</td><td>今天 10:00</td><td>132</td><td>${badge("运行中","success")}</td></tr></tbody></table></div></div>
  </div>`,true);

pages["admin-cert"] = () => shell(`
  <div class="grid grid-4"><div class="card stat-card"><div class="stat-label">应注册人数</div><div class="stat-value">2,316</div></div><div class="card stat-card"><div class="stat-label">已提交</div><div class="stat-value">1,748</div></div><div class="card stat-card"><div class="stat-label">审核通过</div><div class="stat-value">1,596</div></div><div class="card stat-card"><div class="stat-label">待补充</div><div class="stat-value">152</div></div></div>
  <div class="card"><div class="toolbar"><div class="toolbar-left"><input class="input search" placeholder="姓名 / 企业 / 手机号"><select class="select"><option>全部注册状态</option><option>已通过</option><option>审核中</option><option>需补充</option></select></div>${button("导出制证名单","primary",'class="btn primary js-download"')}</div>
    <div class="table-wrap"><table><thead><tr><th>姓名</th><th>企业</th><th>证件类型</th><th>手机号</th><th>身份证明</th><th>注册状态</th><th>提交时间</th><th>操作</th></tr></thead><tbody>
      <tr><td>张敏</td><td>华丰农业科技</td><td>参展商证</td><td>138****2219</td><td>${badge("已上传","success")}</td><td>${badge("已通过","success")}</td><td>07-21 10:18</td><td><span class="link">查看</span></td></tr>
      <tr><td>王成</td><td>华丰农业科技</td><td>参展商证</td><td>186****0832</td><td>${badge("已上传","success")}</td><td>${badge("审核中","warning")}</td><td>07-21 10:22</td><td><span class="link">审核</span></td></tr>
      <tr><td>刘浩</td><td>中科新型肥业</td><td>布展证</td><td>139****5206</td><td>${badge("照片模糊","danger")}</td><td>${badge("需补充","danger")}</td><td>07-20 16:44</td><td><span class="link js-confirm" data-message="已发送补充提醒">提醒</span></td></tr>
    </tbody></table></div>
  </div>`,true);

pages["mini-home"] = () => mobileShell(`
  <div class="mini-hero"><p>我的展会</p><h2>2026 中国国际农业科技展</h2><p>2026.09.18—09.20 · 上海</p><div class="mini-data"><div>展位号<strong>A3-218</strong></div><div>展位类型<strong>绿搭</strong></div></div></div>
  <div class="card"><div class="card-head"><div class="card-title">当前进度</div><strong class="text-success">72%</strong></div><div class="progress"><span style="width:72%"></span></div><div class="list-item"><span class="text-muted">当前事项</span>${badge("绿搭画面需修改","danger")}</div><a href="mini-progress.html" class="btn soft block">查看完整进度</a></div>
  <div class="card"><div class="card-title" style="margin-bottom:15px">快捷服务</div><div class="quick-grid"><a href="mini-progress.html"><div class="quick-icon">◉</div>参展进度</a><a href="mini-cert.html"><div class="quick-icon">♧</div>证件注册</a><a href="mini-notice.html"><div class="quick-icon">▧</div>通知书</a><a href="mini-message.html"><div class="quick-icon">✉</div>消息中心</a></div></div>
  <div class="card"><div class="card-head"><div class="card-title">重要提醒</div>${badge("1 条待处理","danger")}</div><div class="mini-message"><div class="mini-message-icon">!</div><div><strong>画面 2-反审核未通过</strong><div class="list-desc" style="margin-top:5px">存在绝对化宣传用语，请修改后重新提交。</div><div class="mini-message-time">今天 14:32</div></div></div></div>
`,"home","展务服务");

pages["mini-progress"] = () => mobileShell(`
  <div class="card"><div class="card-head"><div><div class="card-title">参展总进度</div><div class="card-sub">5 个流程 · 已完成 2 项</div></div><strong class="text-success">72%</strong></div><div class="progress"><span style="width:72%"></span></div></div>
  <div class="card"><div class="card-title" style="margin-bottom:18px">流程状态</div><div class="timeline">
    <div class="timeline-item done"><span class="timeline-dot"></span><div class="timeline-title">基础信息 ${badge("已确认","success")}</div><div class="timeline-time">2026-07-12 10:20</div><div class="timeline-text">企业及楣板信息已确认。</div></div>
    <div class="timeline-item done"><span class="timeline-dot"></span><div class="timeline-title">资质审核 ${badge("已通过","success")}</div><div class="timeline-time">2026-07-18 16:42</div></div>
    <div class="timeline-item fail"><span class="timeline-dot"></span><div class="timeline-title">绿搭画面 ${badge("已驳回","danger")}</div><div class="timeline-time">2026-07-21 14:32</div><div class="reject-tip">驳回原因：画面 2-反含“全国第一”绝对化宣传用语。</div><button class="btn danger small" style="margin-top:10px">去修改</button></div>
    <div class="timeline-item"><span class="timeline-dot"></span><div class="timeline-title">报到通知书 ${badge("已生成","info")}</div><div class="timeline-time">2026-07-22 09:00</div></div>
    <div class="timeline-item"><span class="timeline-dot"></span><div class="timeline-title">人员证件 ${badge("进行中","warning")}</div><div class="timeline-time">已注册 3 / 6 人</div></div>
  </div></div>
`,"progress","参展进度");

pages["mini-message"] = () => mobileShell(`
  <div class="tabs"><button class="tab-btn active" data-tab="miniall">全部</button><button class="tab-btn" data-tab="minireview">审核</button><button class="tab-btn" data-tab="minisys">系统</button></div>
  <div class="tab-panel active" id="tab-miniall">
    <div class="card"><div class="mini-message"><div class="mini-message-icon">!</div><div><strong>绿搭画面审核未通过</strong><div class="list-desc" style="margin-top:6px">画面 2-反存在绝对化宣传用语，请修改后重新提交。</div><div class="mini-message-time">今天 14:32</div></div></div></div>
    <div class="card"><div class="mini-message"><div class="mini-message-icon" style="background:#fff4dd;color:#b86e00">⌛</div><div><strong>证件注册截止提醒</strong><div class="list-desc" style="margin-top:6px">距截止还有 8 天，当前完成 3/6 人。</div><div class="mini-message-time">昨天 10:00</div></div></div></div>
    <div class="card"><div class="mini-message"><div class="mini-message-icon" style="background:#e8f7ef;color:#18a058">✓</div><div><strong>通知书已生成</strong><div class="list-desc" style="margin-top:6px">您的参展报到通知书已生成，可在线查看。</div><div class="mini-message-time">07-19 16:08</div></div></div></div>
  </div>
  <div class="tab-panel" id="tab-minireview"><div class="card empty">暂无更多审核消息</div></div><div class="tab-panel" id="tab-minisys"><div class="card empty">暂无更多系统消息</div></div>
`,"message","消息中心");

pages["mini-cert"] = () => mobileShell(`
  <div class="card"><div class="card-head"><div><div class="card-title">人员证件注册</div><div class="card-sub">已注册 3 / 6 人</div></div>${badge("进行中","warning")}</div><div class="progress"><span style="width:50%"></span></div></div>
  <div class="card mini-form"><div class="card-title" style="margin-bottom:16px">新增人员</div>
    <div class="field"><label>姓名</label><input class="input" placeholder="请输入真实姓名"></div>
    <div class="field"><label>手机号码</label><input class="input" placeholder="请输入手机号码"></div>
    <div class="field"><label>证件类型</label><select class="select"><option>参展商证</option><option>布展证</option><option>撤展证</option></select></div>
    <div class="field"><label>身份证明</label>${uploadZone("上传身份证正面")}</div>
    <button class="btn primary block js-confirm" data-message="人员信息已提交审核">提交注册</button>
  </div>
  <div class="card"><div class="card-title">已注册人员</div><div class="list-item"><div><strong>张敏</strong><div class="list-desc">参展商证 · 138****2219</div></div>${badge("已通过","success")}</div><div class="list-item"><div><strong>王成</strong><div class="list-desc">参展商证 · 186****0832</div></div>${badge("审核中","warning")}</div></div>
`,"cert","证件注册");

pages["mini-notice"] = () => mobileShell(`
  <div class="card" style="text-align:center"><div style="font-size:38px;margin-bottom:8px">▧</div><div class="card-title">参展商报到通知书</div><div class="card-sub">CAATE-2026-A3-0218</div>${badge("已生成","success")}</div>
  <div class="card"><div class="list-item"><span class="text-muted">展会名称</span><strong style="text-align:right">2026 中国国际<br>农业科技展</strong></div><div class="list-item"><span class="text-muted">参展企业</span><strong style="text-align:right">山东华丰农业<br>科技有限公司</strong></div><div class="list-item"><span class="text-muted">展位号</span><strong>A3-218</strong></div><div class="list-item"><span class="text-muted">报到时间</span><strong style="text-align:right">09月16日<br>09:00—17:00</strong></div><div class="list-item"><span class="text-muted">报到地点</span><strong style="text-align:right">3H 馆参展商服务台</strong></div></div>
  <div class="card"><div class="card-title">报到流程</div><ol style="padding-left:20px;line-height:2;color:#667085"><li>出示电子通知书及企业证件</li><li>核验信息并领取参展证件</li><li>确认展位并办理现场服务</li><li>完成安全检查后进馆布展</li></ol></div>
  <button class="btn primary block js-download">下载 PDF 通知书</button>
`,"","报到通知书");

/* 2026-06 information architecture revision */
enterpriseNav.splice(1, 3,
  ["basic-info.html","basic-info","▤","参展资料"]
);
enterpriseNav.splice(enterpriseNav.findIndex(item => item[1] === "notice"), 1);
adminNav.splice(2, 1,
  ["admin-enterprise.html","admin-enterprise","♙","展商管理"]
);
adminNav.push(["admin-settings.html","admin-settings","⚙","系统设置"]);

meta["basic-info"] = ["参展资料","集中维护企业基础信息、资质档案与宣传物料"];
meta["product-info"] = meta["basic-info"];
meta["brand-info"] = meta["basic-info"];
meta["booth-green"] = ["绿搭管理","在线选择方案规格，按模板提交设计图并处理改稿"];
meta["booth-raw"] = ["光地管理","确认企业名片并提交搭建申报资料"];
meta["admin-enterprise"] = ["展商管理","同步展商数据并维护资料、展位和楣板信息"];
meta["admin-green-detail"] = ["绿搭业务详情","查看单个展商的方案确认、设计稿审核和通知书状态"];
meta["admin-raw-detail"] = ["光地业务详情","查看单个展商的名片确认、搭建材料和通知书状态"];
meta["admin-settings"] = ["系统设置","配置角色权限、违规极限词与业务审核流"];

const combinedInfoPage = () => shell(`
  <div class="card">
    <div class="card-head"><div><div class="card-title">参展资料完整度</div><div class="card-sub">三个资料分类统一提交、统一跟踪审核</div></div><strong class="text-success">86%</strong></div>
    <div class="progress"><span style="width:86%"></span></div>
  </div>
  <div class="card">
    <div class="tabs"><button class="tab-btn active" data-tab="companybase">企业基础信息</button><button class="tab-btn" data-tab="qualification">企业及展品</button><button class="tab-btn" data-tab="promotion">宣传资料</button></div>
    <div class="tab-panel active" id="tab-companybase">
      <div class="card-head"><div><div class="card-title">企业基础信息</div><div class="card-sub">用于会刊、展位名片及通知书生成</div></div>${badge("已确认","success")}</div>
      <div class="form-grid">
        <div class="field"><label>企业名称</label><input class="input" value="山东华丰农业科技有限公司"></div>
        <div class="field"><label>联系人</label><input class="input" value="张敏"></div>
        <div class="field"><label>联系电话</label><input class="input" value="138 6608 2219"></div>
        <div class="field"><label>楣板 / 企业名片名称</label><input class="input" value="山东华丰农业科技有限公司"></div>
      </div>
    </div>
    <div class="tab-panel" id="tab-qualification">
      <div class="field"><label>产品品类</label><div class="check-row"><label class="check"><input type="checkbox" checked> 农药制剂</label><label class="check"><input type="checkbox" checked> 新型肥料</label><label class="check"><input type="checkbox" checked> 生物技术</label><label class="check"><input type="checkbox"> 农业机械</label></div></div>
      <div class="grid grid-3" style="margin-top:18px">
        <div class="upload-card"><div class="upload-name"><span>营业执照</span>${badge("已通过","success")}</div>${fileRow("营业执照_副本.pdf")}</div>
        <div class="upload-card"><div class="upload-name"><span>农药登记证</span>${badge("已通过","success")}</div>${fileRow("农药登记证_PD20260188.pdf")}</div>
        <div class="upload-card"><div class="upload-name"><span>肥料登记证</span>${badge("审核中","warning")}</div>${fileRow("肥料登记证_鲁农肥.pdf","审核中","warning")}</div>
        <div class="upload-card"><div class="upload-name"><span>生产许可证</span>${badge("已通过","success")}</div>${fileRow("生产许可证_2026.pdf")}</div>
        <div class="upload-card"><div class="upload-name"><span>检测报告</span>${badge("需补充","danger")}</div>${uploadZone("重新上传检测报告")}<div class="reject-tip">请上传带 CMA 章的完整报告。</div></div>
      </div>
    </div>
    <div class="tab-panel" id="tab-promotion">
      <div class="grid grid-2">
        <div><div class="card-title" style="margin-bottom:12px">企业 LOGO</div>${uploadZone("替换企业 LOGO")}${fileRow("huafeng-logo-print.png")}</div>
        <div><div class="card-title" style="margin-bottom:12px">会刊资料</div>${uploadZone("上传会刊宣传页")}${fileRow("企业会刊宣传页.pdf","审核中","warning")}</div>
      </div>
      <div class="field" style="margin-top:18px"><label>企业简介</label><textarea class="textarea">山东华丰农业科技有限公司专注于绿色农业投入品研发与生产，为现代农业提供高效、安全、环保的综合解决方案。</textarea></div>
    </div>
    <div class="form-actions">${button("保存草稿","")}${button("统一提交审核","primary",'class="btn primary js-confirm" data-message="参展资料已统一提交审核"')}</div>
  </div>`);
pages["basic-info"] = combinedInfoPage;
pages["product-info"] = combinedInfoPage;
pages["brand-info"] = combinedInfoPage;

pages["booth-green"] = () => shell(`
  <div class="card">
    <div class="tabs"><button class="tab-btn active" data-tab="greenscheme">在线确认方案</button><button class="tab-btn" data-tab="greenrevision">改稿申请</button><button class="tab-btn" data-tab="greennotice">参展报到通知书</button></div>
    <div class="tab-panel active" id="tab-greenscheme">
      <div class="card-head"><div><div class="card-title">第一步：选择绿搭规格</div><div class="card-sub">方案模板由主办方在系统设置中统一配置</div></div>${badge("待企业确认","warning")}</div>
      <div class="choice-grid">
        <div class="choice-card"><h3>标准绿搭 18㎡</h3><div class="text-muted">6m × 3m · 双开口</div><div class="choice-price">18㎡</div><div class="help">适合基础品牌展示</div></div>
        <div class="choice-card selected"><h3>升级绿搭 36㎡</h3><div class="text-muted">6m × 6m · 三开口</div><div class="choice-price">36㎡</div><div class="help">当前已选择 · 模板 G-36-A</div></div>
        <div class="choice-card"><h3>旗舰绿搭 54㎡</h3><div class="text-muted">9m × 6m · 岛型</div><div class="choice-price">54㎡</div><div class="help">适合多产品线展示</div></div>
      </div>
      <div class="card-title" style="margin:24px 0 14px">第二步：下载模板并上传设计图</div>
      <div class="grid grid-2">
        <div class="upload-card"><div class="template-preview"></div><div class="upload-name"><span>G-36-A 设计模板</span>${badge("系统模板","info")}</div><p class="text-muted">包含尺寸、安全区、出血位和画面编号说明。</p><button class="btn block js-download">下载设计模板</button></div>
        <div class="upload-card"><div class="upload-name"><span>企业设计图</span>${badge("审核中","warning")}</div>${uploadZone("上传按模板制作的设计稿")}${fileRow("华丰农业_G-36-A_v3.pdf","审核中","warning")}</div>
      </div>
      <div class="form-actions">${button("保存选择","")}${button("确认方案并提交","primary",'class="btn primary js-confirm" data-message="绿搭规格与设计方案已确认"')}</div>
    </div>
    <div class="tab-panel" id="tab-greenrevision">
      <div class="alert warning">当前设计稿已进入制作确认阶段。如需变更，请先提交改稿申请。</div>
      <div class="table-wrap"><table><thead><tr><th>申请编号</th><th>改稿内容</th><th>申请时间</th><th>状态</th><th>操作</th></tr></thead><tbody>
        <tr><td>GX-20260722-08</td><td>更换主画面产品图及联系电话</td><td>07-22 11:20</td><td>${badge("审核中","warning")}</td><td><span class="link js-detail" data-detail="revision">查看</span></td></tr>
        <tr><td>GX-20260718-03</td><td>调整企业 LOGO 位置</td><td>07-18 09:12</td><td>${badge("已完成","success")}</td><td><span class="link js-confirm" data-message="已打开改稿结果">结果</span></td></tr>
      </tbody></table></div>
      <div class="form-actions">${button("+ 发起改稿申请","primary",'class="btn primary js-modal" data-title="发起改稿申请" data-body="请描述需要修改的画面编号、位置和正确内容，提交后由主办方评估制作影响。"')}</div>
    </div>
    <div class="tab-panel" id="tab-greennotice">
      <div class="notice-paper" style="padding:30px"><h2>绿搭展商参展报到通知书</h2><div class="notice-no">CAATE-GREEN-A3-0218</div><div class="notice-row"><strong>企业</strong><span>山东华丰农业科技有限公司</span></div><div class="notice-row"><strong>展位</strong><span>A3-218 · 36㎡绿搭</span></div><div class="notice-row"><strong>报到时间</strong><span>2026年9月16日 09:00—17:00</span></div><div class="notice-row"><strong>报到地点</strong><span>3H馆绿搭展商服务台</span></div><button class="btn primary block js-download" style="margin-top:22px">下载 PDF 通知书</button></div>
    </div>
  </div>`);

pages["booth-raw"] = () => shell(`
  <div class="card">
    <div class="tabs"><button class="tab-btn active" data-tab="rawcard">企业名片确认</button><button class="tab-btn" data-tab="rawdocs">搭建资料</button><button class="tab-btn" data-tab="rawnotice">参展报到通知书</button></div>
    <div class="tab-panel active" id="tab-rawcard">
      <div class="grid grid-2">
        <div class="business-card"><div class="business-card-logo">HF</div><h2 style="margin:0 0 8px">山东华丰农业科技有限公司</h2><p class="text-muted">SHANDONG HUAFENG AGRITECH CO., LTD.</p><div class="list-item"><span>展位号</span><strong>C2-106</strong></div><div class="list-item"><span>联系人</span><strong>张敏 · 138****2219</strong></div></div>
        <div><div class="card-head"><div><div class="card-title">确认企业名片</div><div class="card-sub">名片用于现场导视、会刊和报到材料</div></div>${badge("待确认","warning")}</div><div class="field"><label>中文企业名</label><input class="input" value="山东华丰农业科技有限公司"></div><div class="field" style="margin-top:15px"><label>英文企业名</label><input class="input" value="SHANDONG HUAFENG AGRITECH CO., LTD."></div><button class="btn primary block js-confirm" data-message="企业名片已确认" style="margin-top:18px">确认企业名片</button></div>
      </div>
    </div>
    <div class="tab-panel" id="tab-rawdocs">
      <div class="grid grid-2">
        <div class="upload-card"><div class="upload-name"><span>搭建商资料</span>${badge("已通过","success")}</div>${fileRow("远景会展搭建商资质.pdf")}</div>
        <div class="upload-card"><div class="upload-name"><span>展位平面图</span>${badge("已通过","success")}</div>${fileRow("C2-106_平面图.pdf")}</div>
        <div class="upload-card"><div class="upload-name"><span>电路图</span>${badge("需修改","danger")}</div>${uploadZone("重新上传电路图")}<div class="reject-tip">请补充配电箱位置和回路编号。</div></div>
        <div class="upload-card"><div class="upload-name"><span>安全承诺书</span>${badge("已通过","success")}</div>${fileRow("安全搭建承诺书.pdf")}</div>
      </div>
      <div class="form-actions">${button("提交搭建资料","primary",'class="btn primary js-confirm" data-message="光地搭建资料已提交"')}</div>
    </div>
    <div class="tab-panel" id="tab-rawnotice">
      <div class="notice-paper" style="padding:30px"><h2>光地展商参展报到通知书</h2><div class="notice-no">CAATE-RAW-C2-0106</div><div class="notice-row"><strong>企业</strong><span>山东华丰农业科技有限公司</span></div><div class="notice-row"><strong>展位</strong><span>C2-106 · 54㎡光地</span></div><div class="notice-row"><strong>搭建商报到</strong><span>2026年9月15日 13:00—17:00</span></div><div class="notice-row"><strong>企业报到</strong><span>2026年9月16日 09:00—17:00</span></div><button class="btn primary block js-download" style="margin-top:22px">下载 PDF 通知书</button></div>
    </div>
  </div>`);

pages["admin-enterprise"] = () => shell(`
  <div class="card"><div class="toolbar"><div class="toolbar-left"><input class="input search" placeholder="搜索展商名称 / 展位号"><select class="select"><option>全部展位类型</option><option>标准展位</option><option>绿搭</option><option>光地</option></select></div><div class="toolbar-right">${button("↻ 同步数据","",'class="btn js-confirm" data-message="已同步 386 条展商数据"')}${button("+ 新增展商","primary",'class="btn primary js-modal" data-title="新增展商" data-body="录入展商基础信息后，可继续分配展位并发送账号邀请。"')}</div></div>
    <div class="table-wrap"><table><thead><tr><th>展商名称</th><th>联系人</th><th>展位号</th><th>展位类型</th><th>楣板 / 名片</th><th>资料状态</th><th>操作</th></tr></thead><tbody>
      <tr><td>山东华丰农业科技有限公司</td><td>张敏<br><span class="text-muted">138****2219</span></td><td><strong>A3-218</strong></td><td>绿搭</td><td>山东华丰农业科技有限公司</td><td>${badge("待修改","danger")}</td><td class="table-actions"><span class="link js-detail" data-detail="enterprise">详情</span><span class="link js-detail" data-detail="edit">编辑</span><span class="link js-detail" data-detail="booth">分配展位</span><span class="link js-detail" data-detail="nameplate">编辑楣板</span></td></tr>
      <tr><td>中科新型肥业有限公司</td><td>刘浩<br><span class="text-muted">139****5206</span></td><td>B1-066</td><td>标准展位</td><td>中科新型肥业</td><td>${badge("资料齐全","success")}</td><td class="table-actions"><span class="link js-detail" data-detail="enterprise">详情</span><span class="link js-detail" data-detail="edit">编辑</span><span class="link js-detail" data-detail="booth">分配展位</span><span class="link js-detail" data-detail="nameplate">编辑楣板</span></td></tr>
      <tr><td>禾润生物技术有限公司</td><td>孙晴</td><td>C2-106</td><td>光地</td><td>禾润生物科技</td><td>${badge("审核中","warning")}</td><td class="table-actions"><span class="link js-detail" data-detail="enterprise">详情</span><span class="link js-detail" data-detail="edit">编辑</span><span class="link js-detail" data-detail="booth">分配展位</span><span class="link js-detail" data-detail="nameplate">编辑名片</span></td></tr>
    </tbody></table></div>
  </div>`,true);

pages["admin-review-green"] = () => shell(`
  <div class="grid grid-4"><div class="card stat-card"><div class="stat-label">待审核方案</div><div class="stat-value">73</div></div><div class="card stat-card"><div class="stat-label">规格已确认</div><div class="stat-value">109</div></div><div class="card stat-card"><div class="stat-label">改稿申请</div><div class="stat-value">12</div></div><div class="card stat-card"><div class="stat-label">通知书已生成</div><div class="stat-value">96</div></div></div>
  <div class="card"><div class="toolbar"><div class="toolbar-left"><input class="input search" placeholder="展商 / 展位号"><select class="select"><option>全部业务状态</option><option>方案待审</option><option>需改稿</option><option>已完成</option></select></div><span class="text-muted">共 132 家绿搭展商</span></div>
    <div class="table-wrap"><table><thead><tr><th>展商 / 展位</th><th>选择规格</th><th>设计稿</th><th>改稿申请</th><th>通知书</th><th>状态</th><th>操作</th></tr></thead><tbody>
      <tr><td>华丰农业科技<br><span class="text-muted">A3-218</span></td><td>36㎡ · G-36-A</td><td>${badge("审核中","warning")}</td><td>1 条处理中</td><td>${badge("已生成","success")}</td><td>${badge("需关注","danger")}</td><td><a class="btn small primary" href="admin-green-detail.html">查看详情</a></td></tr>
      <tr><td>丰源智慧农业<br><span class="text-muted">A2-088</span></td><td>54㎡ · G-54-B</td><td>${badge("已通过","success")}</td><td>无</td><td>${badge("已生成","success")}</td><td>${badge("已完成","success")}</td><td><a class="btn small" href="admin-green-detail.html">查看详情</a></td></tr>
      <tr><td>绿野植保<br><span class="text-muted">B2-109</span></td><td>18㎡ · G-18-A</td><td>${badge("待审核","warning")}</td><td>无</td><td>${badge("待生成","default")}</td><td>${badge("审核中","warning")}</td><td><a class="btn small" href="admin-green-detail.html">查看详情</a></td></tr>
    </tbody></table></div>
  </div>`,true);

pages["admin-review-raw"] = () => shell(`
  <div class="grid grid-4"><div class="card stat-card"><div class="stat-label">光地展商</div><div class="stat-value">58</div></div><div class="card stat-card"><div class="stat-label">名片已确认</div><div class="stat-value">51</div></div><div class="card stat-card"><div class="stat-label">资料待审核</div><div class="stat-value">21</div></div><div class="card stat-card"><div class="stat-label">通知书已生成</div><div class="stat-value">43</div></div></div>
  <div class="card"><div class="table-wrap"><table><thead><tr><th>展商 / 展位</th><th>企业名片</th><th>搭建商资料</th><th>工程图纸</th><th>安全文件</th><th>通知书</th><th>操作</th></tr></thead><tbody>
    <tr><td>禾润生物技术<br><span class="text-muted">C2-106 · 54㎡</span></td><td>${badge("已确认","success")}</td><td>${badge("已通过","success")}</td><td>${badge("需修改","danger")}</td><td>${badge("已通过","success")}</td><td>${badge("已生成","success")}</td><td><a class="btn small primary" href="admin-raw-detail.html">查看详情</a></td></tr>
    <tr><td>农科智造<br><span class="text-muted">D1-016 · 72㎡</span></td><td>${badge("待确认","warning")}</td><td>${badge("审核中","warning")}</td><td>${badge("待审核","warning")}</td><td>${badge("待审核","warning")}</td><td>${badge("待生成","default")}</td><td><a class="btn small" href="admin-raw-detail.html">查看详情</a></td></tr>
  </tbody></table></div></div>`,true);

pages["admin-green-detail"] = () => shell(`
  <div class="toolbar"><a class="btn" href="admin-review-green.html">← 返回绿搭列表</a><div class="toolbar-right">${button("生成参展报到通知书","primary",'class="btn primary js-download"')}</div></div>
  <div class="grid grid-4"><div class="card stat-card"><div class="stat-label">展商</div><div class="stat-value" style="font-size:18px">华丰农业科技</div><div class="stat-foot">A3-218</div></div><div class="card stat-card"><div class="stat-label">方案规格</div><div class="stat-value">36㎡</div><div class="stat-foot">G-36-A</div></div><div class="card stat-card"><div class="stat-label">设计稿</div><div class="stat-value" style="font-size:20px">审核中</div></div><div class="card stat-card"><div class="stat-label">通知书</div><div class="stat-value" style="font-size:20px">已生成</div></div></div>
  <div class="card"><div class="tabs"><button class="tab-btn active" data-tab="gdplan">方案与设计稿</button><button class="tab-btn" data-tab="gdrevision">改稿记录</button><button class="tab-btn" data-tab="gdnotice">报到通知书</button></div>
    <div class="tab-panel active" id="tab-gdplan"><div class="grid grid-2"><div class="effect-card"><img src="assets/green-booth.png"><div class="effect-info"><strong>G-36-A 效果预览</strong>${badge("企业已确认","success")}</div></div><div><div class="info-section"><div class="info-title">规格信息</div><div class="info-pairs"><div class="info-pair"><span>面积</span><strong>36㎡</strong></div><div class="info-pair"><span>开口</span><strong>三开口</strong></div><div class="info-pair"><span>模板</span><strong>G-36-A</strong></div><div class="info-pair"><span>确认时间</span><strong>07-20 10:18</strong></div></div></div><div class="info-section"><div class="info-title">设计文件</div>${fileRow("华丰农业_G-36-A_v3.pdf","审核中","warning")}<div class="form-actions">${button("审核通过","success",'class="btn success js-confirm" data-message="设计稿已审核通过"')}${button("驳回修改","danger",'class="btn danger js-modal" data-title="驳回设计稿" data-body="填写具体画面编号与修改意见，提交后自动通知展商。"')}</div></div></div></div></div>
    <div class="tab-panel" id="tab-gdrevision"><div class="timeline"><div class="timeline-item"><span class="timeline-dot"></span><div class="timeline-title">改稿申请 GX-20260722-08 ${badge("审核中","warning")}</div><div class="timeline-time">07-22 11:20</div><div class="timeline-text">更换主画面产品图及联系电话。</div></div><div class="timeline-item done"><span class="timeline-dot"></span><div class="timeline-title">LOGO 位置调整完成</div><div class="timeline-time">07-18 16:30</div></div></div></div>
    <div class="tab-panel" id="tab-gdnotice"><div class="alert info">报到通知书 CAATE-GREEN-A3-0218 已于 07-22 09:00 生成并推送企业。</div>${button("重新生成 PDF","",'class="btn js-download"')}${button("发送通知","primary",'class="btn primary js-confirm" data-message="通知书已推送给展商"')}</div>
  </div>`,true);

pages["admin-raw-detail"] = () => shell(`
  <div class="toolbar"><a class="btn" href="admin-review-raw.html">← 返回光地列表</a><div class="toolbar-right">${button("生成参展报到通知书","primary",'class="btn primary js-download"')}</div></div>
  <div class="grid grid-3"><div class="card stat-card"><div class="stat-label">展商 / 展位</div><div class="stat-value" style="font-size:18px">禾润生物技术</div><div class="stat-foot">C2-106 · 54㎡</div></div><div class="card stat-card"><div class="stat-label">企业名片</div><div class="stat-value" style="font-size:20px">已确认</div></div><div class="card stat-card"><div class="stat-label">总体审核</div><div class="stat-value" style="font-size:20px">需补正</div></div></div>
  <div class="card"><div class="tabs"><button class="tab-btn active" data-tab="rdcard">企业名片</button><button class="tab-btn" data-tab="rddocs">搭建资料审核</button><button class="tab-btn" data-tab="rdnotice">报到通知书</button></div>
    <div class="tab-panel active" id="tab-rdcard"><div class="business-card"><div class="business-card-logo">HR</div><h2>禾润生物技术有限公司</h2><p class="text-muted">HERUN BIOTECHNOLOGY CO., LTD.</p><div class="info-pairs"><div class="info-pair"><span>联系人</span><strong>孙晴</strong></div><div class="info-pair"><span>联系电话</span><strong>137****6108</strong></div></div></div></div>
    <div class="tab-panel" id="tab-rddocs"><div class="table-wrap"><table><thead><tr><th>资料</th><th>文件</th><th>风险提示</th><th>状态</th><th>操作</th></tr></thead><tbody><tr><td>搭建商资质</td><td>远景会展资质.pdf</td><td>无异常</td><td>${badge("已通过","success")}</td><td><span class="link">预览</span></td></tr><tr><td>平面图</td><td>C2-106_平面图.pdf</td><td>无异常</td><td>${badge("已通过","success")}</td><td><span class="link">预览</span></td></tr><tr><td>电路图</td><td>C2-106_电路图.pdf</td><td class="text-danger">功率标注不一致</td><td>${badge("需修改","danger")}</td><td><span class="link js-modal" data-title="审核电路图" data-body="请填写需修改的功率、回路或配电位置。">处理</span></td></tr><tr><td>安全承诺书</td><td>安全承诺书.pdf</td><td>无异常</td><td>${badge("已通过","success")}</td><td><span class="link">预览</span></td></tr></tbody></table></div></div>
    <div class="tab-panel" id="tab-rdnotice"><div class="alert info">光地展商及搭建商报到时间已写入通知书。</div>${button("下载通知书","primary",'class="btn primary js-download"')}${button("推送展商","",'class="btn js-confirm" data-message="通知书已推送"')}</div>
  </div>`,true);

pages["admin-settings"] = () => shell(`
  <div class="card"><div class="tabs"><button class="tab-btn active" data-tab="roles">角色权限</button><button class="tab-btn" data-tab="words">违规极限词配置</button><button class="tab-btn" data-tab="flows">审核流配置</button><button class="tab-btn" data-tab="templates">绿搭模板配置</button></div>
    <div class="tab-panel active" id="tab-roles"><div class="permission-grid"><div class="role-list"><div class="role-item active">超级管理员</div><div class="role-item">展商管理员</div><div class="role-item">绿搭审核员</div><div class="role-item">光地审核员</div><div class="role-item">证件管理员</div><button class="btn block js-modal" data-title="新增角色" data-body="设置角色名称和数据权限范围。" style="margin-top:12px">+ 新增角色</button></div><div class="permission-main"><div class="card-head"><div><div class="card-title">超级管理员权限</div><div class="card-sub">拥有系统全部数据和功能权限</div></div>${badge("已启用","success")}</div><div class="permission-group"><strong>展商与展位</strong><div class="check-row"><label class="check"><input type="checkbox" checked> 查看</label><label class="check"><input type="checkbox" checked> 新增编辑</label><label class="check"><input type="checkbox" checked> 分配展位</label><label class="check"><input type="checkbox" checked> 导出</label></div></div><div class="permission-group"><strong>业务审核</strong><div class="check-row"><label class="check"><input type="checkbox" checked> 绿搭审核</label><label class="check"><input type="checkbox" checked> 光地审核</label><label class="check"><input type="checkbox" checked> 证件审核</label><label class="check"><input type="checkbox" checked> 通知书管理</label></div></div><div class="form-actions">${button("保存权限","primary",'class="btn primary js-confirm" data-message="角色权限已保存"')}</div></div></div></div>
    <div class="tab-panel" id="tab-words"><div class="toolbar"><div class="toolbar-left"><input class="input search" placeholder="搜索极限词"></div>${button("+ 新增词条","primary",'class="btn primary js-modal" data-title="新增违规极限词" data-body="配置词语、风险等级及命中后的审核策略。"')}</div><div class="table-wrap"><table><thead><tr><th>词语</th><th>分类</th><th>风险等级</th><th>命中策略</th><th>状态</th><th>操作</th></tr></thead><tbody><tr><td><span class="word-flag">全国第一</span></td><td>绝对化用语</td><td>${badge("高风险","danger")}</td><td>阻止自动通过</td><td>${badge("启用","success")}</td><td><span class="link js-detail" data-detail="word">编辑</span></td></tr><tr><td><span class="word-flag">国家级</span></td><td>资质表述</td><td>${badge("中风险","warning")}</td><td>人工复核</td><td>${badge("启用","success")}</td><td><span class="link js-detail" data-detail="word">编辑</span></td></tr><tr><td>百分百有效</td><td>功效承诺</td><td>${badge("高风险","danger")}</td><td>阻止提交</td><td>${badge("启用","success")}</td><td><span class="link js-detail" data-detail="word">编辑</span></td></tr></tbody></table></div></div>
    <div class="tab-panel" id="tab-flows"><div class="grid grid-2"><div class="upload-card"><div class="upload-name"><span>绿搭设计稿审核流</span>${badge("运行中","success")}</div><div class="flow-line"><span class="flow-node">企业提交</span><span class="flow-arrow">→</span><span class="flow-node">系统词检</span><span class="flow-arrow">→</span><span class="flow-node">审核员</span><span class="flow-arrow">→</span><span class="flow-node">企业确认</span></div><button class="btn small js-detail" data-detail="flow" style="margin-top:15px">编辑审核流</button></div><div class="upload-card"><div class="upload-name"><span>光地材料审核流</span>${badge("运行中","success")}</div><div class="flow-line"><span class="flow-node">企业提交</span><span class="flow-arrow">→</span><span class="flow-node">图纸审核</span><span class="flow-arrow">→</span><span class="flow-node">安全审核</span></div><button class="btn small js-detail" data-detail="flow" style="margin-top:15px">编辑审核流</button></div></div></div>
    <div class="tab-panel" id="tab-templates"><div class="toolbar"><span class="text-muted">企业端可选择以下启用模板</span>${button("+ 新增模板","primary",'class="btn primary js-modal" data-title="新增绿搭模板" data-body="设置模板名称、适用规格、尺寸文件与预览效果图。"')}</div><div class="choice-grid"><div class="choice-card selected"><div class="template-preview"></div><h3>G-36-A</h3><div class="text-muted">36㎡ · 三开口</div></div><div class="choice-card"><div class="template-preview"></div><h3>G-18-A</h3><div class="text-muted">18㎡ · 双开口</div></div><div class="choice-card"><div class="template-preview"></div><h3>G-54-B</h3><div class="text-muted">54㎡ · 岛型</div></div></div></div>
  </div>`,true);

mobileShell = function(content, active="home", title="展务服务") {
  const links = [
    ["mini-home.html","home","⌂","首页"],
    ["mini-booth.html","booth","▣","展位业务"],
    ["mini-progress.html","progress","◉","进度"],
    ["mini-cert.html","cert","♧","证件"]
  ];
  return `<div class="mobile-page"><div class="phone">
    <div class="phone-top"><div class="phone-status"><span>09:41</span><span>● ● ▰</span></div><div class="phone-head"><h1>${title}</h1><span>•••</span></div></div>
    <div class="phone-content">${content}</div>
    <nav class="bottom-nav">${links.map(x=>`<a href="${x[0]}" class="${active===x[1]?"active":""}"><span>${x[2]}</span><span>${x[3]}</span></a>`).join("")}</nav>
  </div></div>${globalUI()}`;
};

pages["mini-home"] = () => mobileShell(`
  <div class="mini-hero"><p>我的展会</p><h2>2026 中国国际农业科技展</h2><p>2026.09.18—09.20 · 上海</p><div class="mini-data"><div>展位号<strong>A3-218</strong></div><div>展位类型<strong>绿搭</strong></div></div></div>
  <div class="card"><div class="card-head"><div class="card-title">当前进度</div><strong class="text-success">72%</strong></div><div class="progress"><span style="width:72%"></span></div><div class="list-item"><span class="text-muted">当前事项</span>${badge("设计稿审核中","warning")}</div><a href="mini-progress.html" class="btn soft block">查看完整进度</a></div>
  <div class="card"><div class="card-head"><div class="card-title">展位动态</div>${badge("1 条待处理","danger")}</div><div class="mini-message"><div class="mini-message-icon">!</div><div><strong>改稿申请正在审核</strong><div class="list-desc" style="margin-top:5px">申请编号 GX-20260722-08，预计 1 个工作日内反馈。</div><div class="mini-message-time">今天 14:32</div></div></div></div>
  <div class="card"><div class="card-head"><div class="card-title">报到通知书</div>${badge("已生成","success")}</div><p class="text-muted">绿搭展商报到：2026年9月16日 09:00</p><a href="mini-notice.html" class="btn block">查看通知书</a></div>
`,"home","展务服务");

pages["mini-booth"] = () => mobileShell(`
  <div class="card"><div class="card-head"><div><div class="card-title">我的展位</div><div class="card-sub">A3-218 · 36㎡绿搭</div></div>${badge("业务进行中","warning")}</div><div class="progress"><span style="width:68%"></span></div></div>
  <a class="card booth-menu-card" href="#"><h3>方案与规格确认</h3><p>已选择 36㎡升级绿搭，模板 G-36-A。</p><div style="margin-top:10px">${badge("已确认","success")}</div></a>
  <a class="card booth-menu-card js-upload" href="#"><h3>上传设计图</h3><p>按系统模板上传 PDF / AI 设计文件。</p><div style="margin-top:10px">${badge("审核中","warning")}</div></a>
  <a class="card booth-menu-card js-modal" href="#" data-title="发起改稿申请" data-body="说明需要修改的画面、位置和正确内容。"><h3>改稿申请</h3><p>当前有 1 条申请正在审核。</p><div style="margin-top:10px">${badge("处理中","warning")}</div></a>
  <a class="card booth-menu-card" href="mini-notice.html"><h3>参展报到通知书</h3><p>查看报到时间、地点与展位信息。</p><div style="margin-top:10px">${badge("已生成","success")}</div></a>
`,"booth","展位业务");

const reportNoticeHTML = (boothType="绿搭", boothNo="A3-218") => `
  <div class="notice-paper" style="padding:30px">
    <h2>${boothType}展商参展报到通知书</h2>
    <div class="notice-no">CAATE-2026-${boothNo.replace("-","")}</div>
    <div class="notice-row"><strong>报到时间</strong><span>2026年9月16日 09:00—17:00</span></div>
    <div class="notice-row"><strong>报到地点</strong><span>上海国家会展中心 3H 馆参展商服务台</span></div>
    <div class="notice-row"><strong>展位号</strong><span>${boothNo} · ${boothType}展位</span></div>
    <div class="section-block">
      <div class="info-title">报到流程</div>
      <div class="report-flow"><div class="report-step"><strong>① 签到并领取证件</strong><div class="help">出示通知书及企业有效证件</div></div><span class="flow-arrow">→</span><div class="report-step"><strong>② 办理入场手续</strong><div class="help">核对展位并完成安全登记</div></div></div>
    </div>
    <div class="section-block"><div class="info-title">注意事项</div><ul class="notice-list"><li><strong>展品运输：</strong>车辆须按指定物流通道和预约时段进场，大件展品请提前申报。</li><li><strong>进场资料：</strong>请携带本通知书、营业执照复印件、参展人员身份证明及相关运输单据。</li></ul></div>
    <div class="section-block"><div class="info-title">现场对接人</div><div class="info-pairs"><div class="info-pair"><span>对接人</span><strong>李悦</strong></div><div class="info-pair"><span>联系电话</span><strong>138 0013 8000</strong></div><div class="info-pair"><span>服务电话</span><strong>021-8888 6600</strong></div><div class="info-pair"><span>服务时间</span><strong>09:00—18:00</strong></div></div></div>
    <button class="btn primary block js-download" style="margin-top:22px">下载 PDF 通知书</button>
  </div>`;

const enterpriseInfoPage = () => shell(`
  <div class="card">
    <div class="card-head"><div><div class="card-title">参展资料完整度</div><div class="card-sub">资料默认以查看状态展示，点击页面底部“编辑资料”后方可修改</div></div><strong class="text-success">86%</strong></div>
    <div class="progress"><span style="width:86%"></span></div>
    <div class="section-block">
      <div class="section-heading"><div><h3>企业基础资料</h3><div class="card-sub">用于会刊、展位名片及通知书生成</div></div>${badge("已确认","success")}</div>
      <div class="form-grid"><div class="field"><label>企业名称</label><input class="input" value="山东华丰农业科技有限公司"></div><div class="field"><label>联系人</label><input class="input" value="张敏"></div><div class="field"><label>联系电话</label><input class="input" value="138 6608 2219"></div><div class="field"><label>楣板 / 企业名片名称</label><input class="input" value="山东华丰农业科技有限公司"></div></div>
    </div>
    <div class="section-block">
      <div class="section-heading"><div><h3>企业及展品</h3><div class="card-sub">产品分类及企业资质档案</div></div>${badge("检测报告需补充","danger")}</div>
      <div class="field"><label>产品品类</label><div class="check-row"><label class="check"><input type="checkbox" checked> 农药制剂</label><label class="check"><input type="checkbox" checked> 新型肥料</label><label class="check"><input type="checkbox" checked> 生物技术</label><label class="check"><input type="checkbox"> 农业机械</label></div></div>
      <div class="grid grid-3" style="margin-top:16px"><div class="upload-card"><div class="upload-name"><span>营业执照</span>${badge("已通过","success")}</div>${fileRow("营业执照_副本.pdf")}</div><div class="upload-card"><div class="upload-name"><span>登记证</span>${badge("已通过","success")}</div>${fileRow("农药登记证_PD20260188.pdf")}</div><div class="upload-card"><div class="upload-name"><span>检测报告</span>${badge("需补充","danger")}</div>${uploadZone("重新上传检测报告")}<div class="reject-tip">请上传带 CMA 章的完整报告。</div></div></div>
    </div>
    <div class="section-block">
      <div class="section-heading"><div><h3>宣传资料</h3><div class="card-sub">LOGO、会刊宣传页及企业简介</div></div>${badge("审核中","warning")}</div>
      <div class="grid grid-2"><div class="upload-card"><div class="upload-name"><span>企业 LOGO</span>${badge("已上传","success")}</div>${fileRow("huafeng-logo-print.png")}${uploadZone("替换企业 LOGO")}</div><div class="upload-card"><div class="upload-name"><span>会刊资料</span>${badge("审核中","warning")}</div>${fileRow("企业会刊宣传页.pdf","审核中","warning")}${uploadZone("替换会刊宣传页")}</div></div>
      <div class="field" style="margin-top:16px"><label>企业简介</label><textarea class="textarea">山东华丰农业科技有限公司专注于绿色农业投入品研发与生产，为现代农业提供高效、安全、环保的综合解决方案。</textarea></div>
    </div>
  </div>`);
pages["basic-info"] = enterpriseInfoPage;
pages["product-info"] = enterpriseInfoPage;
pages["brand-info"] = enterpriseInfoPage;

pages.notice = () => shell(`<div class="toolbar"><div></div><div>${button("下载 PDF","primary",'class="btn primary js-download"')}</div></div>${reportNoticeHTML("绿搭","A3-218")}`);

pages["admin-exhibition"] = () => shell(`
  <div class="toolbar"><div class="toolbar-left"><select class="select"><option>2026 中国国际农业科技展</option><option>2025 农业科技创新展</option></select>${badge("进行中","success")}</div>${button("+ 创建展会","primary",'class="btn primary js-modal" data-title="创建新展会" data-body="填写展会名称、举办时间及场馆信息后即可创建展会。"')}</div>
  <div class="card">
    <div class="section-block"><div class="section-heading"><div><h3>基础配置</h3><div class="card-sub">展会名称、举办场馆和开展时间</div></div>${badge("已配置","success")}</div><div class="form-grid"><div class="field"><label>展会名称</label><input class="input" value="2026 中国国际农业科技展"></div><div class="field"><label>展会地点</label><input class="input" value="上海国家会展中心"></div><div class="field"><label>开展日期</label><input class="input" type="date" value="2026-09-18"></div><div class="field"><label>结束日期</label><input class="input" type="date" value="2026-09-20"></div></div></div>
    <div class="section-block"><div class="section-heading"><div><h3>展位类型配置</h3><div class="card-sub">配置不同展位适用的资料流程</div></div>${button("+ 新增类型","small",'class="btn small js-modal" data-title="新增展位类型" data-body="配置展位名称、面积范围和适用业务流程。"')}</div><div class="table-wrap"><table><thead><tr><th>类型</th><th>规格</th><th>企业数</th><th>资料流程</th><th>状态</th></tr></thead><tbody><tr><td>标准展位</td><td>3m × 3m</td><td>196</td><td>名片确认 + 证件</td><td>${badge("启用","success")}</td></tr><tr><td>绿搭展位</td><td>18—72㎡</td><td>132</td><td>规格方案 + 设计稿 + 通知书</td><td>${badge("启用","success")}</td></tr><tr><td>光地展位</td><td>36㎡起</td><td>58</td><td>名片 + 搭建资料 + 通知书</td><td>${badge("启用","success")}</td></tr></tbody></table></div></div>
    <div class="section-block"><div class="section-heading"><div><h3>截止时间配置</h3><div class="card-sub">到期前系统自动发送短信和站内信提醒</div></div>${badge("自动提醒已开启","info")}</div><div class="form-grid"><div class="field"><label>基础资料截止</label><input class="input" type="datetime-local" value="2026-07-15T18:00"></div><div class="field"><label>企业资质截止</label><input class="input" type="datetime-local" value="2026-07-22T18:00"></div><div class="field"><label>绿搭 / 光地截止</label><input class="input" type="datetime-local" value="2026-07-30T18:00"></div><div class="field"><label>证件注册截止</label><input class="input" type="datetime-local" value="2026-08-15T18:00"></div></div></div>
    <div class="form-actions">${button("保存全部配置","primary",'class="btn primary js-confirm" data-message="展会全部配置已保存"')}</div>
  </div>`,true);

pages["admin-enterprise"] = () => shell(`
  <div class="card"><div class="toolbar"><div class="toolbar-left"><input class="input search" placeholder="搜索展商名称 / 展位号"><select class="select"><option>全部展位类型</option><option>标准展位</option><option>绿搭</option><option>光地</option></select></div><div class="toolbar-right">${button("↻ 同步数据","",'class="btn js-confirm" data-message="已同步 386 条展商数据"')}${button("+ 新增展商","primary",'class="btn primary js-modal" data-title="新增展商" data-body="录入展商基础信息后发送账号邀请。"')}</div></div>
  <div class="table-wrap"><table><thead><tr><th>展商名称</th><th>联系人</th><th>展位号</th><th>展位类型</th><th>楣板 / 名片</th><th>资料状态</th><th>操作</th></tr></thead><tbody><tr><td>山东华丰农业科技有限公司</td><td>张敏<br><span class="text-muted">138****2219</span></td><td><strong>A3-218</strong></td><td>绿搭</td><td>山东华丰农业科技有限公司</td><td>${badge("待修改","danger")}</td><td class="table-actions"><span class="link js-detail" data-detail="enterprise">详情</span><span class="link js-detail" data-detail="edit">编辑</span></td></tr><tr><td>中科新型肥业有限公司</td><td>刘浩</td><td>B1-066</td><td>标准展位</td><td>中科新型肥业</td><td>${badge("资料齐全","success")}</td><td class="table-actions"><span class="link js-detail" data-detail="enterprise">详情</span><span class="link js-detail" data-detail="edit">编辑</span></td></tr><tr><td>禾润生物技术有限公司</td><td>孙晴</td><td>C2-106</td><td>光地</td><td>禾润生物科技</td><td>${badge("审核中","warning")}</td><td class="table-actions"><span class="link js-detail" data-detail="enterprise">详情</span><span class="link js-detail" data-detail="edit">编辑</span></td></tr></tbody></table></div></div>`,true);

pages["admin-message"] = () => shell(`
  <div class="grid grid-4"><div class="card stat-card"><div class="stat-label">今日短信</div><div class="stat-value">1,286</div></div><div class="card stat-card"><div class="stat-label">短信送达率</div><div class="stat-value">98.7%</div></div><div class="card stat-card"><div class="stat-label">启用模板</div><div class="stat-value">8</div></div><div class="card stat-card"><div class="stat-label">发送失败</div><div class="stat-value">12</div></div></div>
  <div class="grid grid-2" style="margin-top:16px">
    <div class="card"><div class="card-head"><div><div class="card-title">推送短信</div><div class="card-sub">选择模板并向指定展商发送</div></div>${badge("短信通道正常","success")}</div><div class="field"><label>接收对象</label><select class="select"><option>全部绿搭展商（132）</option><option>全部光地展商（58）</option><option>资料未完成展商（46）</option><option>手动选择展商</option></select></div><div class="field" style="margin-top:15px"><label>短信模板</label><select class="select"><option>资料截止提醒</option><option>审核驳回通知</option><option>报到通知书生成提醒</option></select></div><div class="field" style="margin-top:15px"><label>短信预览</label><textarea class="textarea">【农业科技展】尊敬的${"${企业名称}"}，您的参展资料将于${"${截止时间}"}截止，请及时登录展务系统完成提交。</textarea><div class="help">预计发送 132 条，变量将在发送时自动替换。</div></div><button class="btn primary block js-modal" data-title="确认推送短信" data-body="即将向 132 家绿搭展商发送资料截止提醒，是否继续？">推送短信</button></div>
    <div class="card"><div class="card-head"><div><div class="card-title">短信模板配置</div><div class="card-sub">配置可复用的短信内容和变量</div></div>${button("+ 新增模板","primary small",'class="btn primary small js-modal" data-title="新增短信模板" data-body="填写模板名称、适用场景和短信正文，可使用企业名称、截止时间等变量。"')}</div><ul class="list"><li class="list-item"><div><div class="list-title">资料截止提醒</div><div class="list-desc">变量：企业名称、截止时间</div></div><div>${badge("已启用","success")} <span class="link js-detail" data-detail="sms">编辑</span></div></li><li class="list-item"><div><div class="list-title">审核驳回通知</div><div class="list-desc">变量：企业名称、审核事项、驳回原因</div></div><div>${badge("已启用","success")} <span class="link js-detail" data-detail="sms">编辑</span></div></li><li class="list-item"><div><div class="list-title">报到通知书生成提醒</div><div class="list-desc">变量：企业名称、展位号、报到时间</div></div><div>${badge("已启用","success")} <span class="link js-detail" data-detail="sms">编辑</span></div></li></ul></div>
  </div>
  <div class="card"><div class="card-head"><div class="card-title">短信推送记录</div><span class="text-muted">最近 30 天</span></div><div class="table-wrap"><table><thead><tr><th>模板</th><th>接收对象</th><th>发送时间</th><th>发送数量</th><th>送达率</th><th>状态</th></tr></thead><tbody><tr><td>绿搭资料截止提醒</td><td>132 家绿搭展商</td><td>07-22 10:00</td><td>132</td><td>98.5%</td><td>${badge("发送完成","success")}</td></tr><tr><td>报到通知书生成提醒</td><td>278 家已生成企业</td><td>07-20 09:00</td><td>278</td><td>99.1%</td><td>${badge("发送完成","success")}</td></tr></tbody></table></div></div>`,true);

pages["admin-settings"] = () => shell(`
  <div class="card"><div class="tabs"><button class="tab-btn active" data-tab="roles">角色权限</button><button class="tab-btn" data-tab="words">违规极限词配置</button><button class="tab-btn" data-tab="flows">审核流配置</button><button class="tab-btn" data-tab="templates">绿搭模板配置</button></div>
    <div class="tab-panel active" id="tab-roles"><div class="permission-grid"><div class="role-list"><div class="role-item active">超级管理员</div><div class="role-item">展商管理员</div><div class="role-item">绿搭审核员</div><div class="role-item">光地审核员</div></div><div class="permission-main"><div class="card-title">超级管理员权限</div><div class="permission-group"><strong>展商与业务</strong><div class="check-row"><label class="check"><input type="checkbox" checked> 展商管理</label><label class="check"><input type="checkbox" checked> 绿搭审核</label><label class="check"><input type="checkbox" checked> 光地审核</label><label class="check"><input type="checkbox" checked> 消息通知</label></div></div><div class="form-actions">${button("保存权限","primary",'class="btn primary js-confirm" data-message="角色权限已保存"')}</div></div></div></div>
    <div class="tab-panel" id="tab-words"><div class="toolbar"><span class="text-muted">系统在设计稿提交时自动检查</span>${button("+ 新增词条","primary",'class="btn primary js-modal" data-title="新增违规极限词" data-body="配置词语、风险等级及命中策略。"')}</div><div class="table-wrap"><table><thead><tr><th>词语</th><th>分类</th><th>风险等级</th><th>命中策略</th><th>操作</th></tr></thead><tbody><tr><td><span class="word-flag">全国第一</span></td><td>绝对化用语</td><td>${badge("高风险","danger")}</td><td>阻止自动通过</td><td><span class="link js-detail" data-detail="word">编辑</span></td></tr><tr><td>百分百有效</td><td>功效承诺</td><td>${badge("高风险","danger")}</td><td>阻止提交</td><td><span class="link js-detail" data-detail="word">编辑</span></td></tr></tbody></table></div></div>
    <div class="tab-panel" id="tab-flows"><div class="grid grid-2"><div class="upload-card"><div class="upload-name"><span>绿搭设计稿审核流</span>${badge("运行中","success")}</div><div class="flow-line"><span class="flow-node">企业提交</span><span>→</span><span class="flow-node">系统词检</span><span>→</span><span class="flow-node">人工审核</span></div></div><div class="upload-card"><div class="upload-name"><span>光地材料审核流</span>${badge("运行中","success")}</div><div class="flow-line"><span class="flow-node">企业提交</span><span>→</span><span class="flow-node">图纸审核</span><span>→</span><span class="flow-node">安全审核</span></div></div></div></div>
    <div class="tab-panel" id="tab-templates">
      <div class="toolbar"><div><div class="card-title">绿搭模板及上传画面配置</div><div class="card-sub">配置每个面积规格要求企业上传的画面数量及画面名称</div></div>${button("+ 新增模板","primary",'class="btn primary js-detail" data-detail="template"')}</div>
      <div class="template-config-row"><strong>模板 / 规格</strong><strong>面积</strong><strong>画面数量</strong><strong>画面名称</strong><strong>操作</strong></div>
      <div class="template-config-row"><div><strong>G-30-A</strong><div class="help">标准三开口绿搭</div></div><div>30㎡</div><div><input class="input" type="number" value="4"></div><div><div class="template-face-list"><span class="face-tag">1-1</span><span class="face-tag">1-2</span><span class="face-tag">1-3</span><span class="face-tag">1-4</span></div></div><div><span class="link js-detail" data-detail="template">编辑</span></div></div>
      <div class="template-config-row"><div><strong>G-36-A</strong><div class="help">升级三开口绿搭</div></div><div>36㎡</div><div><input class="input" type="number" value="6"></div><div><div class="template-face-list"><span class="face-tag">1-正</span><span class="face-tag">1-反</span><span class="face-tag">2-正</span><span class="face-tag">2-反</span><span class="face-tag">3-1</span><span class="face-tag">3-2</span></div></div><div><span class="link js-detail" data-detail="template">编辑</span></div></div>
      <div class="template-config-row"><div><strong>G-54-B</strong><div class="help">旗舰岛型绿搭</div></div><div>54㎡</div><div><input class="input" type="number" value="8"></div><div><div class="template-face-list"><span class="face-tag">A-1</span><span class="face-tag">A-2</span><span class="face-tag">B-1</span><span class="face-tag">B-2</span><span class="face-tag">C-1</span><span class="face-tag">C-2</span><span class="face-tag">D-1</span><span class="face-tag">D-2</span></div></div><div><span class="link js-detail" data-detail="template">编辑</span></div></div>
      <div class="form-actions">${button("保存模板配置","primary",'class="btn primary js-confirm" data-message="绿搭模板及画面配置已保存"')}</div>
    </div>
  </div>`,true);

pages["mini-notice"] = () => mobileShell(`
  <div class="card" style="text-align:center"><div style="font-size:38px;margin-bottom:8px">▧</div><div class="card-title">参展报到通知书</div><div class="card-sub">CAATE-2026-A3-0218</div>${badge("已生成","success")}</div>
  <div class="card"><div class="list-item"><span class="text-muted">报到时间</span><strong style="text-align:right">09月16日<br>09:00—17:00</strong></div><div class="list-item"><span class="text-muted">报到地点</span><strong style="text-align:right">3H 馆展商服务台</strong></div><div class="list-item"><span class="text-muted">展位号</span><strong>A3-218</strong></div></div>
  <div class="card"><div class="card-title">报到流程</div><div class="report-flow"><div class="report-step">① 签到领证件</div><span class="flow-arrow">→</span><div class="report-step">② 办理入场手续</div></div></div>
  <div class="card"><div class="card-title">注意事项</div><ul class="notice-list"><li>展品运输须预约进场时段，大件展品提前申报。</li><li>携带通知书、营业执照复印件及身份证明。</li></ul></div>
  <div class="card"><div class="card-title">现场对接人</div><div class="list-item"><span>李悦</span><strong>138 0013 8000</strong></div><a class="btn primary block" href="tel:13800138000">联系对接人</a></div>
  <button class="btn primary block js-download">下载 PDF 通知书</button>
`,"","报到通知书");

document.getElementById("app").innerHTML = (pages[page] || pages.dashboard)();

if (document.getElementById("tab-greennotice")) document.getElementById("tab-greennotice").innerHTML = reportNoticeHTML("绿搭","A3-218");
if (document.getElementById("tab-rawnotice")) document.getElementById("tab-rawnotice").innerHTML = reportNoticeHTML("光地","C2-106");

const editableEnterprisePages = ["basic-info","product-info","brand-info","booth-standard","booth-green","booth-raw"];
if (editableEnterprisePages.includes(page)) {
  const content = document.querySelector(".content");
  content.classList.add("enterprise-view-mode");
  content.insertAdjacentHTML("beforeend", `<div class="enterprise-edit-bar"><button class="btn success js-confirm-info">确认信息</button><button class="btn primary js-enter-edit">编辑</button><div class="editing-actions"><button class="btn js-cancel-edit">取消</button><button class="btn js-save-draft">保存草稿</button><button class="btn primary js-submit-edit">提交审核</button></div></div>`);
}

const toast = (text) => {
  const el = document.getElementById("toast");
  if (!el) return;
  el.textContent = "✓ " + text;
  el.classList.add("show");
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(() => el.classList.remove("show"), 2200);
};

document.addEventListener("click", (e) => {
  const tab = e.target.closest(".tab-btn");
  if (tab) {
    const box = tab.closest(".card") || document;
    box.querySelectorAll(".tab-btn").forEach(x=>x.classList.remove("active"));
    box.querySelectorAll(".tab-panel").forEach(x=>x.classList.remove("active"));
    tab.classList.add("active");
    const panel = box.querySelector("#tab-"+tab.dataset.tab);
    if (panel) panel.classList.add("active");
  }
  const modalBtn = e.target.closest(".js-modal");
  if (modalBtn) {
    document.getElementById("modalTitle").textContent = modalBtn.dataset.title || "操作确认";
    document.getElementById("modalBody").innerHTML = `<p>${modalBtn.dataset.body || "请确认本次操作。"}</p><div class="field"><label>备注说明</label><textarea class="textarea" style="min-height:90px" placeholder="请输入说明（模拟）"></textarea></div>`;
    document.getElementById("actionModal").classList.add("open");
  }
  if (e.target.closest(".modal-close")) document.getElementById("actionModal").classList.remove("open");
  if (e.target.closest(".modal-submit")) {
    document.getElementById("actionModal").classList.remove("open");
    toast("申请已提交");
  }
  const confirmBtn = e.target.closest(".js-confirm");
  if (confirmBtn) toast(confirmBtn.dataset.message || "操作成功");
  if (e.target.closest(".js-download")) toast("已生成模拟下载任务");
  const upload = e.target.closest(".js-upload");
  if (upload) {
    upload.innerHTML = `<div><div class="upload-icon text-success">✓</div><div>文件选择成功</div><div class="help">prototype-file.pdf · 等待提交</div></div>`;
    toast("文件已添加");
  }
  const statusBtn = e.target.closest(".js-status");
  if (statusBtn) {
    statusBtn.textContent = "已通过";
    statusBtn.disabled = true;
    statusBtn.classList.remove("success");
    toast("单项审核已通过");
  }
});

const detailContent = {
  enterprise: {
    title: "展商详情",
    body: `<div class="info-section"><div class="info-title">企业基础信息</div><div class="info-pairs"><div class="info-pair"><span>企业名称</span><strong>山东华丰农业科技有限公司</strong></div><div class="info-pair"><span>联系人</span><strong>张敏</strong></div><div class="info-pair"><span>电话</span><strong>138 6608 2219</strong></div><div class="info-pair"><span>展位</span><strong>A3-218 · 绿搭</strong></div></div></div><div class="info-section"><div class="info-title">企业资质档案</div>${fileRow("营业执照_副本.pdf")}${fileRow("农药登记证_PD20260188.pdf")}${fileRow("检测报告_CMA.pdf","需补充","danger")}</div><div class="info-section"><div class="info-title">宣传物料</div>${fileRow("huafeng-logo-print.png")}${fileRow("企业会刊宣传页.pdf","审核中","warning")}</div>`
  },
  edit: {
    title: "编辑展商信息",
    body: `<div class="form-grid"><div class="field"><label>企业名称</label><input class="input" value="山东华丰农业科技有限公司"></div><div class="field"><label>联系人</label><input class="input" value="张敏"></div><div class="field"><label>联系电话</label><input class="input" value="138 6608 2219"></div><div class="field"><label>展商状态</label><select class="select"><option>正常参展</option><option>暂停</option></select></div></div>`
  },
  booth: {
    title: "分配展位",
    body: `<div class="field"><label>展馆</label><select class="select"><option>3H 农业投入品馆</option><option>2H 智慧农业馆</option></select></div><div class="form-grid" style="margin-top:15px"><div class="field"><label>展位号</label><input class="input" value="A3-218"></div><div class="field"><label>展位类型</label><select class="select"><option>绿搭</option><option>标准展位</option><option>光地</option></select></div></div><div class="alert info" style="margin-top:15px">A3-218 当前可用，面积 36㎡。</div>`
  },
  nameplate: {
    title: "编辑楣板 / 企业名片",
    body: `<div class="field"><label>中文名称</label><input class="input" value="山东华丰农业科技有限公司"></div><div class="field" style="margin-top:15px"><label>英文名称</label><input class="input" value="SHANDONG HUAFENG AGRITECH CO., LTD."></div><div class="help">修改后将同步更新会刊、现场导视和通知书。</div>`
  },
  revision: {
    title: "改稿申请详情",
    body: `<div class="info-pairs"><div class="info-pair"><span>申请编号</span><strong>GX-20260722-08</strong></div><div class="info-pair"><span>申请状态</span><strong>${badge("审核中","warning")}</strong></div><div class="info-pair"><span>涉及画面</span><strong>1-正、2-反</strong></div><div class="info-pair"><span>提交时间</span><strong>07-22 11:20</strong></div></div><div class="alert info" style="margin-top:15px">更换主画面产品图，并将联系电话调整为 400-860-2219。</div>`
  },
  word: {
    title: "编辑违规极限词",
    body: `<div class="field"><label>词语</label><input class="input" value="全国第一"></div><div class="form-grid" style="margin-top:15px"><div class="field"><label>风险等级</label><select class="select"><option>高风险</option><option>中风险</option><option>提示</option></select></div><div class="field"><label>命中策略</label><select class="select"><option>阻止自动通过</option><option>人工复核</option><option>阻止提交</option></select></div></div>`
  },
  flow: {
    title: "编辑审核流",
    body: `<div class="alert info">拖动节点可调整顺序（原型模拟）。</div><div class="flow-line"><span class="flow-node">企业提交</span><span class="flow-arrow">→</span><span class="flow-node">系统词检</span><span class="flow-arrow">→</span><span class="flow-node">初审</span><span class="flow-arrow">→</span><span class="flow-node">复审</span></div><button class="btn small" style="margin-top:16px">+ 添加审核节点</button>`
  }
};

detailContent.sms = {
  title: "编辑短信模板",
  body: `<div class="field"><label>模板名称</label><input class="input" value="资料截止提醒"></div><div class="field" style="margin-top:15px"><label>短信正文</label><textarea class="textarea">【农业科技展】尊敬的\${企业名称}，您的参展资料将于\${截止时间}截止，请及时登录展务系统完成提交。</textarea><div class="help">可用变量：企业名称、截止时间、展位号、审核事项、驳回原因</div></div><div class="check-row" style="margin-top:15px"><label class="check"><input type="checkbox" checked> 启用模板</label><label class="check"><input type="checkbox" checked> 记录发送结果</label></div>`
};
detailContent.template = {
  title: "编辑绿搭模板",
  body: `<div class="form-grid"><div class="field"><label>模板名称</label><input class="input" value="G-30-A"></div><div class="field"><label>适用面积</label><input class="input" value="30㎡"></div><div class="field"><label>上传画面数量</label><input class="input js-face-count" type="number" value="4" min="1"></div><div class="field"><label>模板文件</label><button class="btn block js-upload">上传模板文件</button></div></div><div class="field" style="margin-top:15px"><label>画面名称（每行一个）</label><textarea class="textarea">1-1
1-2
1-3
1-4</textarea><div class="help">画面名称数量应与要求上传的画面数量一致。</div></div>`
};

document.addEventListener("click", (e) => {
  const detail = e.target.closest(".js-detail");
  if (detail) {
    e.preventDefault();
    const config = detailContent[detail.dataset.detail] || detailContent.enterprise;
    const modal = document.getElementById("actionModal");
    document.getElementById("modalTitle").textContent = config.title;
    document.getElementById("modalBody").innerHTML = config.body;
    modal.querySelector(".modal-box").classList.add("wide");
    modal.classList.add("open");
  }
  const choice = e.target.closest(".choice-card");
  if (choice) {
    const grid = choice.closest(".choice-grid");
    if (grid) grid.querySelectorAll(".choice-card").forEach(x => x.classList.remove("selected"));
    choice.classList.add("selected");
  }
  if (e.target.closest(".modal-close") || e.target.closest(".modal-submit")) {
    const box = document.querySelector("#actionModal .modal-box");
    if (box) box.classList.remove("wide");
  }
});

document.addEventListener("click", (e) => {
  const content = document.querySelector(".content");
  if (e.target.closest(".js-enter-edit")) {
    content.classList.remove("enterprise-view-mode");
    content.classList.add("enterprise-editing");
    toast("已进入编辑状态");
  }
  if (e.target.closest(".js-confirm-info")) toast("当前信息已确认");
  if (e.target.closest(".js-cancel-edit")) {
    content.classList.remove("enterprise-editing");
    content.classList.add("enterprise-view-mode");
    toast("已取消编辑");
  }
  if (e.target.closest(".js-save-draft")) {
    content.classList.remove("enterprise-editing");
    content.classList.add("enterprise-view-mode");
    toast("草稿已保存");
  }
  if (e.target.closest(".js-submit-edit")) {
    content.classList.remove("enterprise-editing");
    content.classList.add("enterprise-view-mode");
    toast("资料已提交审核");
  }
});
